document.addEventListener("DOMContentLoaded", function () {
  const blogProductListTemplate = document.querySelector('.blog-product-list-template');
  if (!blogProductListTemplate) return;
  const wrappers = blogProductListTemplate.querySelectorAll('.blog-product-list-wrapper');
  if (!wrappers.length) return;

  wrappers.forEach(function (wrapper) {
    const target = wrapper?.getAttribute('data-target');
    if (!target) return;

    const sourceAnchor = document.querySelector(`.article-template__content a[href="${target}"]`);
    if (!sourceAnchor) return;

    const wrappingElement = sourceAnchor.closest('p, span');
    const clonedWrapper = wrapper?.cloneNode(true);

    if (clonedWrapper) {
      if (wrappingElement && wrappingElement.contains(sourceAnchor)) {
        wrappingElement.insertAdjacentElement('afterend', clonedWrapper);
        wrappingElement.remove();
      } else {
        sourceAnchor.insertAdjacentElement('afterend', clonedWrapper);
        sourceAnchor.remove();
      }
    }
  });
});
