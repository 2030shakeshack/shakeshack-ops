if (!customElements.get('wf-announcement')) {
  customElements.define('wf-announcement', class extends HTMLElement {
    connectedCallback() {
      if (this.events) return;

      this.messages = [...this.querySelectorAll('[data-wfa-duration]')];
      if (this.messages.length < 2) return;

      this.activeIndex = this.messages.findIndex((message) => message.hasAttribute('data-wfa-active'));
      this.events = new AbortController();
      const options = { signal: this.events.signal };
      this.hovered = false;
      this.motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');

      this.motionPreference.addEventListener('change', () => this.schedule(), options);
      this.addEventListener('pointerenter', (event) => {
        if (event.pointerType !== 'mouse') return;
        this.hovered = true;
        this.schedule();
      }, options);
      this.addEventListener('pointerleave', (event) => {
        if (event.pointerType !== 'mouse') return;
        this.hovered = false;
        this.schedule();
      }, options);
      this.addEventListener('focusin', () => this.schedule(), options);
      this.addEventListener('focusout', () => queueMicrotask(() => this.schedule()), options);
      document.addEventListener('visibilitychange', () => this.schedule(), options);
      this.schedule();
    }

    disconnectedCallback() {
      this.events?.abort();
      this.events = null;
      clearTimeout(this.timer);
    }

    schedule() {
      clearTimeout(this.timer);
      if (!this.isConnected || this.motionPreference.matches || this.hovered || document.hidden) return;
      if (this.messages.includes(document.activeElement)) return;

      const current = this.messages[this.activeIndex];
      this.timer = setTimeout(() => {
        this.activeIndex = (this.activeIndex + 1) % this.messages.length;
        const next = this.messages[this.activeIndex];

        current.removeAttribute('data-wfa-active');
        current.setAttribute('aria-hidden', 'true');
        current.tabIndex = -1;
        next.setAttribute('data-wfa-active', '');
        next.removeAttribute('aria-hidden');
        next.removeAttribute('tabindex');
        this.schedule();
      }, Number(current.dataset.wfaDuration));
    }
  });
}
