
class CartUpsellRecommendations extends Carousel {
  constructor() {
    super();
    this.productIds = JSON.parse(this.dataset.productIds) || [];
    this.intent = this.dataset.intent;
    this.limit = this.dataset.limit || 4;
    this.cartUpsellShimmerContainer = this.querySelector('.upsell-products-shimmer-container');
  }

  connectedCallback() {
    if (!this.intent) return;
    this.badgeSyncScheduled = false;
    this.listElement = this.querySelector('.splide__list');
    if (this.listElement) {
      this.badgeObserver = new MutationObserver(() => this.scheduleBadgeSync());
      this.badgeObserver.observe(this.listElement, { childList: true, subtree: true });
    }

    const loadRecommendations = async () => {
      try {
        this.cartUpsellShimmerContainer?.classList.remove('hidden');
        const localePrefix = this.dataset.localePrefix || '';
        const langPrefix = localePrefix === '/' ? '' : localePrefix;

        const urls = this.productIds.map(id => `${langPrefix}/recommendations/products?product_id=${id}&limit=${this.limit}&intent=${this.intent}&section_id=upsell-recommendations`);
        const responses = await Promise.all(urls.map(url => fetch(url)));
        for (let response of responses) {
          const text = await response.text();
          const html = document.createElement('div');
          html.innerHTML = text;
          const recommendations = html.querySelectorAll('[data-upsell-card]');
          if (this.querySelectorAll('[data-upsell-card]').length < this.limit) {

            // ── Instant filtering using data-tags on marmeto-product-card ──
            const numRecommendationsToAdd = Math.min(this.limit - this.querySelectorAll('[data-upsell-card]').length, recommendations.length);
            const fragment = document.createDocumentFragment();
            let added = 0;

            for (let i = 0; i < recommendations.length && added < numRecommendationsToAdd; i++) {
              const card = recommendations[i];
              const productCard = card.querySelector('marmeto-product-card');
              const tags = productCard ? (productCard.dataset.tags || '').toLowerCase() : '';

              if (tags && tags.includes('upsell-only')) continue;

              fragment.appendChild(card);
              added++;
            }

            this.querySelector('.splide__list').appendChild(fragment);
          }
        }
        this.cartUpsellShimmerContainer?.classList.add('hidden');
        if (this.querySelectorAll('[data-upsell-card]').length) {
          this.querySelector('.cart-upsell-header')?.classList.remove('hidden');
          this.querySelector('h3')?.classList.remove('hidden');
          this.refreshSlider();
          this.scheduleBadgeSync();
        }
      } catch (error) {
        console.error(error);
      }
    };

    loadRecommendations();
  }

  disconnectedCallback() {
    this.badgeObserver?.disconnect();
  }

  scheduleBadgeSync() {
    if (this.badgeSyncScheduled) return;
    this.badgeSyncScheduled = true;
    requestAnimationFrame(async () => {
      this.badgeSyncScheduled = false;
      await this.syncUpsellBadges();
    });
  }

  async syncUpsellBadges() {
    const includeTag = (this.dataset.badgeIncludeTag || '').toLowerCase().trim();
    const excludeTag = (this.dataset.badgeExcludeTag || '').toLowerCase().trim();
    const badgeLabelOne = this.dataset.badgeLabelOne || '';
    const badgeLabelTwo = this.dataset.badgeLabelTwo || '';
    const badgeColorOne = this.dataset.badgeColorOne || '';
    const badgeColorTwo = this.dataset.badgeColorTwo || '';
    if (!includeTag && !excludeTag && !badgeLabelOne && !badgeLabelTwo) return;

    const cards = Array.from(this.querySelectorAll('[data-upsell-card] marmeto-product-card'));
    if (!cards.length) return;

    cards.forEach(card => {
      const badgeContainer = card.querySelector('.tw-isolate') || card;
      this.ensureBadge(badgeContainer, '.badge--custom', 'badge--custom', badgeLabelOne, badgeColorOne, false);
      this.ensureBadge(badgeContainer, '.badge--custom-2', 'badge--custom-2', badgeLabelTwo, badgeColorTwo, true);
    });

    if (!includeTag && !excludeTag) return;

    const handleTags = new Map();
    cards.forEach(card => {
      const handle = card.dataset.productHandle;
      const tagList = (card.dataset.tags || '').toLowerCase();
      if (handle && tagList) {
        handleTags.set(handle, tagList);
      }
    });

    cards.forEach(card => {
      const handle = card.dataset.productHandle;
      if (!handle || !handleTags.has(handle)) return;
      const tagList = handleTags.get(handle);
      const hasInclude = includeTag && tagList.includes(includeTag);
      const hasExclude = excludeTag && tagList.includes(excludeTag);

      const badgeOne = card.querySelector('.badge--custom');
      const badgeTwo = card.querySelector('.badge--custom-2');

      if (badgeTwo) {
        badgeTwo.classList.toggle('hidden', !hasInclude);
      }
      if (badgeOne && excludeTag) {
        badgeOne.classList.toggle('hidden', hasExclude);
      }
    });
  }

  ensureBadge(container, selector, badgeClass, labelText, colorScheme, hiddenDefault) {
    let badge = container.querySelector(selector);
    if (!badge && labelText) {
      badge = document.createElement('span');
      const colorClass = colorScheme ? ` color-${colorScheme}` : '';
      const hiddenClass = hiddenDefault ? ' hidden' : '';
      badge.className = `badge ${badgeClass}${hiddenClass}${colorClass}`.trim();
      badge.textContent = labelText;
      container.prepend(badge);
    }
    return badge;
  }
}

customElements.define('cart-upsell-recommendations', CartUpsellRecommendations);