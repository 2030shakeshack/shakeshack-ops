// class ProductGallery extends Carousel {
//     constructor() {
//       super();
//       //only for desktop
//       if (window.innerWidth > 750) {
//         this.initiateZoom();
//       }
//       this.variantFilter = this.carouselElement.dataset['variantfilter'] === 'true' || false;
//     }
  
//     initiateZoom() {
//       if (!Drift) return;
//       // Zoom can be customize to show zoomed item in different panel of screen
//       // Read more about library https://github.com/imgix/drift
//       let driftImgs = this.carouselElement.querySelectorAll('.slot-item img[data-zoom]');
  
//       driftImgs.forEach(img => {
//         new Drift(img, {
//           zoomFactor: 2.2,
//           containInline: true,
//           inlinePane: true,
//           handleTouch: false
//         });
//       });
//     }
  
//     showAllMedia() {
//       let allItems = this.carouselElement.querySelectorAll('[data-filter]');
//       let allThumbnailItems = this.syncElement.querySelectorAll('[data-filter]');
  
//       allItems.forEach(element => {
//         element.classList.add('splide__slide');
//         element.classList.remove('hidden');
//       });
  
//       allThumbnailItems.forEach(element => {
//         element.classList.add('splide__slide');
//         element.classList.remove('hidden');
//       });
  
//       this.refreshSlider();
//     }
  
//     filterMedia(media) {
//       this.showAllMedia();

//       let filterSlides = this.carouselElement.querySelectorAll( `[data-filter]:not([data-filter="${media?.alt}"])` );
//       let filterSlidesThumbnails = this.syncElement.querySelectorAll( `[data-filter]:not([data-filter="${media?.alt}"])` );
  
//       filterSlides.forEach(element => {
//         element.classList.remove('splide__slide');
//         element.classList.add('hidden');
//       });
  
//       filterSlidesThumbnails.forEach(element => {
//         element.classList.remove('splide__slide');
//         element.classList.add('hidden');
//       });
//       this.refreshSlider();
//     }
  
//     setActiveMedia(media) {
//       if(this.variantFilter && media?.alt){
//         this.filterMedia(media);
//       }
  
//       let Slides = this.carousel.Components.Slides.filter( `li[data-media-id="${media?.id}"]:not(.splide__slide--clone)` );
//       if ( Slides[ 0 ] ) {
//         this.refreshSlider();
//         this.carousel.go( Slides[ 0 ].index );
//       }
//     }
//   }

//   customElements.define('product-gallery', ProductGallery);

class ProductGallery extends Carousel {
    constructor() {
      super();
      //only for desktop
      if (window.innerWidth > 750) {
        this.initiateZoom();
      }
      this.variantFilter = this.carouselElement.dataset['variantfilter'] === 'true' || false;

      // Apply RTL direction fix for Arabic (or any RTL locale)
      this.applyDirectionFix();
    }
  
    applyDirectionFix() {
      const direction = this.carouselElement.dataset.direction || 'ltr';
      if (direction !== 'rtl') return;

      const apply = () => {
        if (!this.carousel) return;

        // Capture all current options BEFORE destroying
        const existingOptions = { ...this.carousel.options };

        // Destroy the LTR instance
        this.carousel.destroy();

        // Re-initialize with RTL, preserving every existing option exactly
        this.carousel = new Splide(this.carouselElement, {
          ...existingOptions,
          direction: 'rtl',
          // Ensure desktop perPage is preserved explicitly
          perPage: existingOptions.perPage || parseInt(this.carouselElement.dataset.desktopperpage) || 1,
          perMove: existingOptions.perMove || 1,
          breakpoints: existingOptions.breakpoints || {
            750: {
              perPage: parseInt(this.carouselElement.dataset.mobileperpage) || 1,
            }
          }
        });

        this.carousel.mount();
      };

      // If carousel is already initialized, apply immediately
      // Otherwise defer to next tick to allow base class async init to complete
      if (this.carousel) {
        apply();
      } else {
        setTimeout(apply, 0);
      }
    }

    initiateZoom() {
      if (!Drift) return;
      // Zoom can be customize to show zoomed item in different panel of screen
      // Read more about library https://github.com/imgix/drift
      let driftImgs = this.carouselElement.querySelectorAll('.slot-item img[data-zoom]');
  
      driftImgs.forEach(img => {
        new Drift(img, {
          zoomFactor: 2.2,
          containInline: true,
          inlinePane: true,
          handleTouch: false
        });
      });
    }
  
    showAllMedia() {
      let allItems = this.carouselElement.querySelectorAll('[data-filter]');
      let allThumbnailItems = this.syncElement.querySelectorAll('[data-filter]');
  
      allItems.forEach(element => {
        element.classList.add('splide__slide');
        element.classList.remove('hidden');
      });
  
      allThumbnailItems.forEach(element => {
        element.classList.add('splide__slide');
        element.classList.remove('hidden');
      });
  
      this.refreshSlider();
    }
  
    filterMedia(media) {
      this.showAllMedia();

      let filterSlides = this.carouselElement.querySelectorAll( `[data-filter]:not([data-filter="${media?.alt}"])` );
      let filterSlidesThumbnails = this.syncElement.querySelectorAll( `[data-filter]:not([data-filter="${media?.alt}"])` );
  
      filterSlides.forEach(element => {
        element.classList.remove('splide__slide');
        element.classList.add('hidden');
      });
  
      filterSlidesThumbnails.forEach(element => {
        element.classList.remove('splide__slide');
        element.classList.add('hidden');
      });
      this.refreshSlider();
    }
  
    setActiveMedia(media) {
      if(this.variantFilter && media?.alt){
        this.filterMedia(media);
      }
  
      let Slides = this.carousel.Components.Slides.filter( `li[data-media-id="${media?.id}"]:not(.splide__slide--clone)` );
      if ( Slides[ 0 ] ) {
        this.refreshSlider();
        this.carousel.go( Slides[ 0 ].index );
      }
    }
  }

  customElements.define('product-gallery', ProductGallery);
