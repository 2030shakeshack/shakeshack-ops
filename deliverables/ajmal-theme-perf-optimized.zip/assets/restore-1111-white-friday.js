(() => {
  class WhiteFridayQuantity extends HTMLElement {
    connectedCallback() {
      this.form = this.closest('form');
      this.productForm = this.closest('product-form');
      this.group = this.querySelector('[data-wf-limit]');
      if (!this.form || !this.group) return;

      this.controller = new AbortController();
      const { signal } = this.controller;
      this.sticky = this.querySelector('[data-wf-sticky]');
      this.submit = this.form.querySelector('button[name="add"]');
      this.field = this.form.elements.namedItem('quantity');
      this.variant = this.form.elements.namedItem('id');
      if (!this.field || !this.variant || !this.submit) return;

      this.group.addEventListener('click', (event) => {
        const button = event.target.closest('[data-wf-qty]');
        if (!button || button.disabled) return;
        this.field.value = button.dataset.wfQty;
        this.field.dispatchEvent(new Event('change', { bubbles: true }));
        this.refresh();
      }, { signal });

      this.sticky.querySelector('[data-wf-sticky-add]').addEventListener('click', () => {
        if (!this.submit.disabled && this.submit.getAttribute('aria-disabled') !== 'true') this.submit.click();
      }, { signal });

      this.field.addEventListener('change', () => this.refresh(), { signal });
      if (typeof subscribe === 'function' && typeof PUB_SUB_EVENTS !== 'undefined') {
        this.quantitySubscription = subscribe(PUB_SUB_EVENTS.quantityUpdate, () => this.refresh());
      }

      this.mobile = window.matchMedia('(max-width: 749px)');
      const queueStickyUpdate = () => {
        if (this.stickyFrame) return;
        this.stickyFrame = requestAnimationFrame(() => {
          this.stickyFrame = 0;
          this.updateSticky();
        });
      };
      window.addEventListener('scroll', queueStickyUpdate, { passive: true, signal });
      window.addEventListener('resize', queueStickyUpdate, { signal });
      this.submitObserver = new MutationObserver(() => this.updateSticky());
      this.submitObserver.observe(this.submit, { attributes: true, attributeFilter: ['disabled','aria-disabled'] });
      this.refresh();
    }

    refresh() {
      const available = Math.max(0, Number(this.group.dataset.wfLimit) - Number(this.field.dataset.cartQuantity || 0));
      const limit = this.field.max && Number(this.field.max) > 0 ? Math.min(available, Number(this.field.max)) : available;
      const enabled = this.dataset.variant === this.variant.value && limit >= 2;
      this.hidden = !enabled;
      this.toggleAttribute('data-wf-active', enabled);
      const quantity = Number(this.field.value || 1);
      for (const button of this.group.querySelectorAll('[data-wf-qty]')) {
        button.disabled = Number(button.dataset.wfQty) > limit;
        const selected = Number(button.dataset.wfQty) === quantity;
        button.setAttribute('aria-pressed', String(selected));
        if (selected) {
          this.sticky.querySelector('[data-wf-sticky-selection]').textContent =
            button.querySelector('span').textContent + ' · ' + button.querySelector('strong').textContent.trim();
        }
      }
      this.updateSticky();
    }

    updateSticky() {
      this.sticky.hidden = this.hidden || !this.mobile.matches || this.submit.disabled || this.submit.getBoundingClientRect().bottom >= 0;
      this.sticky.querySelector('[data-wf-sticky-add]').disabled = this.submit.getAttribute('aria-disabled') === 'true';
    }

    disconnectedCallback() {
      this.controller?.abort();
      cancelAnimationFrame(this.stickyFrame);
      this.submitObserver?.disconnect();
      this.quantitySubscription?.();
    }
  }
  if (!customElements.get('white-friday-quantity')) customElements.define('white-friday-quantity', WhiteFridayQuantity);

  if (typeof subscribe === 'function' && typeof PUB_SUB_EVENTS !== 'undefined') {
    subscribe(PUB_SUB_EVENTS.variantChange, ({ data }) => {
      if (!data?.html) return;
      for (const current of document.querySelectorAll('white-friday-quantity')) {
        const next = data.html.querySelector(`white-friday-quantity[data-wf-quantity="${CSS.escape(current.dataset.wfQuantity)}"]`);
        if (next) current.replaceWith(next.cloneNode(true));
      }
    });
  }

  const dialog = document.getElementById('WhiteFridayPairPrompt');
  if (!dialog || typeof dialog.showModal !== 'function') return;
  const add = dialog.querySelector('[data-wf-add]');
  const view = dialog.querySelector('[data-wf-view]');
  const keep = dialog.querySelector('[data-wf-close]');
  const error = dialog.querySelector('[data-wf-error]');
  const art = dialog.querySelector('[data-wf-art]');
  const images = art.querySelectorAll('[data-wf-image]');
  let pending;

  images[0].addEventListener('error', () => { art.hidden = true; });

  dialog.addEventListener('cancel', (event) => {
    if (add.disabled) event.preventDefault();
  });
  dialog.addEventListener('close', () => {
    const selection = pending;
    pending = undefined;
    if (!selection) return;
    if (selection.result.sections) {
      selection.form.cart.renderContents(selection.result, dialog.returnValue === 'cart');
    } else {
      location.assign(window.routes.cart_url);
    }
  });
  view.addEventListener('click', () => dialog.close('cart'));
  keep.addEventListener('click', () => dialog.close());

  add.addEventListener('click', async () => {
    if (!pending || add.disabled) return;
    add.disabled = view.disabled = keep.disabled = true;
    error.hidden = true;
    try {
      const body = new FormData();
      for (const [key, value] of pending.data.entries()) body.append(key, value);
      body.set('quantity', '1');
      const response = await fetch(window.routes.cart_add_url, {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json' },
        body,
      });
      const result = await response.json();
      if (!response.ok || result.status) {
        error.textContent = dialog.dataset.error;
        error.hidden = false;
        return;
      }
      pending.result = result;
      publish(PUB_SUB_EVENTS.cartUpdate, {
        source: 'product-form',
        productVariantId: body.get('id'),
        cartData: result,
      });
      dialog.close('cart');
    } catch {
      error.textContent = dialog.dataset.error;
      error.hidden = false;
    } finally {
      add.disabled = view.disabled = keep.disabled = false;
    }
  });

  window.AjmalWhiteFriday = {
    offerAfterAdd(form, data, result) {
      const offer = form.closest('[data-wf-card]')?.querySelector('[data-wf-offer]');
      if (!offer || pending || !result.sections || String(data.get('id')) !== offer.dataset.variant) return false;
      if (Number(data.get('quantity') || 1) !== 1 || !result.quantity || result.quantity % 2 === 0) return false;
      if (result.quantity >= Number(offer.dataset.limit)) return false;
      const freebie = window.freebieModalState || {};
      if (document.getElementById('FreebieModal') && !freebie.selected && !freebie.skip) return false;

      const name = result.product_title || result.title || '';
      const { unit, half, halfLabel, pair, each } = offer.dataset;
      const description = dialog.dataset.description.replace(/\[product\]|\[price\]/g, (token) =>
        token === '[product]' ? name : halfLabel
      );
      const content = { description, unit, half, total: pair, each, increase: `+${halfLabel}` };
      for (const [key, value] of Object.entries(content)) {
        dialog.querySelector(`[data-wf-${key}]`).textContent = value;
      }
      const imageUrl = offer.dataset.art || result.featured_image?.url || result.image;
      art.hidden = !imageUrl;
      if (imageUrl) images.forEach((image) => { image.src = imageUrl; });
      error.hidden = true;
      dialog.returnValue = '';
      try {
        dialog.showModal();
      } catch {
        return false;
      }
      pending = { form, data, result };
      return true;
    },
  };
})();
