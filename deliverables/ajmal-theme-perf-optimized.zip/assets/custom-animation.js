function initializeScrollAnimationTrigger(rootEl = document) {
  const elements = rootEl.querySelectorAll(
    '.scroll-trigger.animate--fade-in, .scroll-trigger.animate--slide-in'
  );

  if (!('IntersectionObserver' in window)) {
    elements.forEach((element) => {
      element.classList.remove('scroll-trigger--offscreen');
    });
    return;
  }

  const rootMargin = window.matchMedia('(max-width: 749px)').matches
    ? '0px 0px -75px 0px'
    : '0px 0px -50px 0px';

  elements.forEach((element) => {
    if (
      element.dataset.scrollAnimationInitialized === 'true' ||
      element.classList.contains('scroll-trigger--design-mode')
    ) {
      return;
    }

    element.dataset.scrollAnimationInitialized = 'true';

    const observer = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.remove('scroll-trigger--offscreen');
          observer.unobserve(entry.target);
        }
      });
    }, {
      rootMargin: rootMargin,
    });

    observer.observe(element);
  });
}

function initializeAllScrollAnimations() {
  initializeScrollAnimationTrigger(document);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeAllScrollAnimations, { once: true });
} else {
  initializeAllScrollAnimations();
}

document.addEventListener('shopify:section:load', (event) => {
  initializeScrollAnimationTrigger(event.target);
});