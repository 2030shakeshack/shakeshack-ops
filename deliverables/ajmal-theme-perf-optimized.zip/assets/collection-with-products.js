if (!customElements.get("collection-products")) {
    class CollectionProducts extends Carousel {
      constructor() {
        super();
        this.sectionId = this.dataset?.sectionId;
        this.collectionProductsContainer = document.querySelector(`.collection-products-${this.sectionId}`);
        if (!this.sectionId || !this.collectionProductsContainer) {
          console.error("CollectionProducts: Missing sectionId or collection container.");
          return;
        }
        if (!this.carousel?.Components?.Elements?.list) {
          console.error("CollectionProducts: Carousel components not found.");
          return;
        }
        this.allSlides = this.carousel.Components.Elements.list.children;
        this.carousel.on("moved", (newIndex) => this.replaceContent(newIndex));
      }
      replaceContent(newIndex) {
        const currentSlide = this.allSlides?.[newIndex];
        if (!currentSlide) {
          console.error("CollectionProducts: Invalid slide index.");
          return;
        }
        const collectionHandle = currentSlide.getAttribute("data-collection-handle");
        if (!collectionHandle) {
          console.error("CollectionProducts: Missing data-collection-handle on slide.");
          return;
        }
        const allCollectionContainers = this.collectionProductsContainer.querySelectorAll(".collection-products");
        allCollectionContainers?.forEach((element) => {
          element.classList.toggle("hidden", element.getAttribute("data-collection-handle") !== collectionHandle);
        });
      }
    }
    customElements.define("collection-products", CollectionProducts);
  }
  