class TestYourFragrance extends HTMLElement {
  constructor() {
    super();
    this.videoPosters = this.querySelectorAll(".test-your-fragrance-poster");
    this.allProducts = this.querySelectorAll(".test-your-fragrance-product");
    this.allVideosContainer = this.querySelectorAll(".test-your-fragrance-video");
    this.allVideos = this.querySelectorAll('.test-your-fragrance-video video');
    this.allCloseButtons = this.querySelectorAll('.close-popup-button');
    this.isAutoplay = this.getAttribute('data-autoplay') === 'true';
    if (!this.videoPosters.length && !this.allProducts.length) return;
    this.isMobileView = window.innerWidth < 750;
    this.initEventListeners();
    if (this.isAutoplay) this.observeSection();
  }

  initEventListeners() {
    this.videoPosters.forEach(poster => poster.addEventListener("click", this.loadContent.bind(this)));
    this.allProducts.forEach(product => product.addEventListener("click", this.playActiveVideo.bind(this)));
    this.allCloseButtons.forEach(button => button.addEventListener("click", this.reloadVideo.bind(this)));
  }

  playActiveVideo(event) {
    this.allVideosContainer.forEach(video => video.classList.add("hidden"));
    this.allProducts.forEach(product => product.classList.remove("intially-active-product"));

    const closestProduct = event.target.closest(".test-your-fragrance-product");
    if (!closestProduct) return console.error("No closest product found!");

    const activeIndex = closestProduct.getAttribute("data-index-number");
    const activeVideoContainer = this.querySelector(`.test-your-fragrance-video-${activeIndex}`);
    const activeVideoElement = activeVideoContainer?.querySelector(`.video-section__media.${this.isMobileView ? "mobile-video" : "desktop-video"}`);

    if (closestProduct) closestProduct.classList.add("intially-active-product");
    if (activeVideoContainer) activeVideoContainer.classList.remove("hidden");

    this.loadContent(null, activeVideoElement);
  }

  loadContent(event, videoElement) {
    try {
      this.allVideos.forEach(video => { video.currentTime = 0; });

      const target = event?.target;
      const closestVideoContainer = target?.closest('.video-section__media') || videoElement;
      const video = closestVideoContainer?.querySelector('video');
      const videoPopup = closestVideoContainer?.closest('.test-your-fragrance-video')?.querySelector('.test-your-fragrance-popup-container');

      if (typeof window.pauseAllMedia === "function") window.pauseAllMedia();

      if (video) {
        closestVideoContainer.closest('.test-your-fragrance-video')?.setAttribute('data-video-playing', 'true');
        video.play().catch(err => console.error("Error playing video:", err));
        video.onended = () => this.showPopup(videoPopup, closestVideoContainer);
      }
    } catch (error) {
      console.error("Error loading video content:", error);
    }
  }

  observeSection() {
    this.sectionObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) {
          this.allVideosContainer.forEach(container => container.querySelector("video")?.pause());
          return;
        }
        const activeVideoContainer = [...this.allVideosContainer].find(video => !video.classList.contains("hidden"));
        const activeVideoElement = activeVideoContainer?.querySelector(`.video-section__media.${this.isMobileView ? "mobile-video" : "desktop-video"}`);

        if (activeVideoElement && this.isAutoplay) {
          this.loadContent(null, activeVideoElement);
        }
      });
    }, { root: null, threshold: 0.75 });

    this.sectionObserver.observe(this);
  }

  showPopup(videoPopup, videoPosterButton) {
    videoPosterButton?.querySelector(`.video-section__media.${this.isMobileView ? "mobile-video" : "desktop-video"} .video-section__poster`)?.classList.add('show');
    videoPopup?.classList.add("show");
  }

  reloadVideo(event) {
    if (!event) return;
    const closestVideoContainer = event.target.closest('.test-your-fragrance-video');
    const videoElement = closestVideoContainer?.querySelector(`.video-section__media.${this.isMobileView ? "mobile-video" : "desktop-video"} video`);

    if (videoElement) {
      closestVideoContainer?.removeAttribute('data-video-playing');
      videoElement.currentTime = 0;
      videoElement.pause();
    }

    closestVideoContainer?.querySelector(`.video-section__media.${this.isMobileView ? "mobile-video" : "desktop-video"} .video-section__poster`)?.classList.remove('show');
    closestVideoContainer?.querySelector('.test-your-fragrance-popup-container')?.classList.remove("show");
    this.loadContent(null, closestVideoContainer?.querySelector(`.video-section__media.${this.isMobileView ? "mobile-video" : "desktop-video"}`));
  }

  disconnectedCallback() {
    this.videoPosters.forEach(poster => poster.removeEventListener("click", this.loadContent));
    this.allProducts.forEach(product => product.removeEventListener("click", this.playActiveVideo));
    this.allCloseButtons.forEach(button => button.removeEventListener("click", this.reloadVideo));

    if (this.isAutoplay && this.sectionObserver) this.sectionObserver.disconnect();
  }
}

customElements.define("test-your-fragrance", TestYourFragrance);