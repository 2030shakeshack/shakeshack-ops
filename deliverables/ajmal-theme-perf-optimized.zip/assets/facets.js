class FacetFiltersForm extends HTMLElement {
  constructor() {
    super();
    this.onActiveFilterClick = this.onActiveFilterClick.bind(this);

    this.debouncedOnSubmit = debounce((event) => {
      this.onSubmitHandler(event);
    }, 500);

    const facetForm = this.querySelector('form');
    facetForm.addEventListener('input', this.debouncedOnSubmit.bind(this));

    const facetWrapper = this.querySelector('#FacetsWrapperDesktop');
    if (facetWrapper) facetWrapper.addEventListener('keyup', onKeyUpEscape);
  }

  static setListeners() {
    const onHistoryChange = (event) => {
      const searchParams = event.state ? event.state.searchParams : FacetFiltersForm.searchParamsInitial;
      if (searchParams === FacetFiltersForm.searchParamsPrev) return;
      FacetFiltersForm.renderPage(searchParams, null, false);
    };
    window.addEventListener('popstate', onHistoryChange);
  }

  static toggleActiveFacets(disable = true) {
    document.querySelectorAll('.js-facet-remove').forEach((element) => {
      element.classList.toggle('disabled', disable);
    });
  }

  static renderPage(searchParams, event, updateURLHash = true) {
    FacetFiltersForm.renderController?.abort();
    const controller = new AbortController();
    FacetFiltersForm.renderController = controller;
    FacetFiltersForm.searchParamsPrev = searchParams;
    const sections = FacetFiltersForm.getSections();
    const countContainer = document.getElementById('ProductCount');
    const countContainerDesktop = document.getElementById('ProductCountDesktop');
    document.getElementById('ProductGridContainer').querySelector('.collection').classList.add('loading');
    if (countContainer) {
      countContainer.classList.add('loading');
    }
    if (countContainerDesktop) {
      countContainerDesktop.classList.add('loading');
    }

    sections.forEach((section) => {
      const url = `${window.location.pathname}?section_id=${section.section}&${searchParams}`;
      const cached = FacetFiltersForm.filterData.find((entry) => entry.url === url);
      if (cached) FacetFiltersForm.renderSection(cached.html, event);
      else FacetFiltersForm.renderSectionFromFetch(url, event, controller.signal);
    });

    if (updateURLHash) FacetFiltersForm.updateURLHash(searchParams);
  }

  static renderSectionFromFetch(url, event, signal) {
    fetch(url, { signal })
      .then((response) => {
        if (!response.ok) throw new Error(`Facet request failed: ${response.status}`);
        return response.text();
      })
      .then((html) => {
        if (signal.aborted) return;
        FacetFiltersForm.renderSection(html, event);
        FacetFiltersForm.filterData.push({ html, url });
      })
      .catch((error) => {
        if (signal.aborted) return;
        console.error(error);
        document.querySelectorAll('#ProductGridContainer .collection.loading, #ProductCount.loading, #ProductCountDesktop.loading')
          .forEach((element) => element.classList.remove('loading'));
        FacetFiltersForm.toggleActiveFacets(false);
      });
  }

  static renderSection(html, event) {
    const parsed = new DOMParser().parseFromString(html, 'text/html');
    FacetFiltersForm.renderFilters(parsed, event);
    FacetFiltersForm.renderProductGridContainer(parsed);
    FacetFiltersForm.renderProductCount(parsed);
    if (typeof initializeScrollAnimationTrigger === 'function') initializeScrollAnimationTrigger();
  }

  static renderProductGridContainer(parsed) {
    document.getElementById('ProductGridContainer').innerHTML = parsed.getElementById('ProductGridContainer').innerHTML;

    document
      .getElementById('ProductGridContainer')
      .querySelectorAll('.scroll-trigger')
      .forEach((element) => {
        element.classList.add('scroll-trigger--cancel');
      });
  }

  static renderProductCount(updatedData) {
    const count = updatedData.getElementById('ProductCount')?.innerHTML;
    const desktopCount = updatedData.getElementById('ProductCountDesktop')?.innerHTML || null;
    const container = document.getElementById('ProductCount');
    const containerDesktop = document.getElementById('ProductCountDesktop');
    if (container && count ) {
      container.innerHTML = count;
      container.classList.remove('loading');
    }
    if (containerDesktop && desktopCount ) {
      containerDesktop.innerHTML = desktopCount;
      containerDesktop.classList.remove('loading');
    }
  }

  static renderFilters(parsedHTML, event) {
    const facetDetailsElements = parsedHTML.querySelectorAll(
      '#FacetFiltersForm .js-filter, #FacetFiltersFormMobile .js-filter, #FacetFiltersPillsForm .js-filter'
    );
    const matchesIndex = (element) => {
      const jsFilter = event ? event.target.closest('.js-filter') : undefined;
      return jsFilter ? element.dataset.index === jsFilter.dataset.index : false;
    };
    const facetsToRender = Array.from(facetDetailsElements).filter((element) => !matchesIndex(element));
    const countsToRender = Array.from(facetDetailsElements).find(matchesIndex);

    facetsToRender.forEach((element) => {
      document.querySelector(`.js-filter[data-index="${element.dataset.index}"]`).innerHTML = element.innerHTML;
    });

    FacetFiltersForm.renderActiveFacets(parsedHTML);
    FacetFiltersForm.renderAdditionalElements(parsedHTML);

    if (countsToRender) FacetFiltersForm.renderCounts(countsToRender, event.target.closest('.js-filter'));
  }

  static renderActiveFacets(html) {
    const activeFacetElementSelectors = ['.active-facets-mobile', '.active-facets-desktop'];

    activeFacetElementSelectors.forEach((selector) => {
      const activeFacetsElement = html.querySelector(selector);
      if (!activeFacetsElement) return;
      document.querySelector(selector).innerHTML = activeFacetsElement.innerHTML;
    });

    FacetFiltersForm.toggleActiveFacets(false);
  }

  static renderAdditionalElements(html) {
    const mobileElementSelectors = ['.mobile-facets__open', '.mobile-facets__count', '.sorting'];

    mobileElementSelectors.forEach((selector) => {
      if (!html.querySelector(selector)) return;
      document.querySelector(selector).innerHTML = html.querySelector(selector).innerHTML;
    });

    document.getElementById('FacetFiltersFormMobile').closest('menu-drawer').bindEvents();
  }

  static renderCounts(source, target) {
    const targetElement = target.querySelector('.facets__selected');
    const sourceElement = source.querySelector('.facets__selected');

    const targetElementAccessibility = target.querySelector('.facets__summary');
    const sourceElementAccessibility = source.querySelector('.facets__summary');

    if (sourceElement && targetElement) {
      target.querySelector('.facets__selected').outerHTML = source.querySelector('.facets__selected').outerHTML;
    }

    if (targetElementAccessibility && sourceElementAccessibility) {
      target.querySelector('.facets__summary').outerHTML = source.querySelector('.facets__summary').outerHTML;
    }
  }

  static updateURLHash(searchParams) {
    history.pushState({ searchParams }, '', `${window.location.pathname}${searchParams && '?'.concat(searchParams)}`);
  }

  static getSections() {
    return [
      {
        section: document.getElementById('product-grid').dataset.id,
      },
    ];
  }

  createSearchParams(form) {
    const formData = new FormData(form);
    return new URLSearchParams(formData).toString();
  }

  onSubmitForm(searchParams, event) {
    FacetFiltersForm.renderPage(searchParams, event);
  }

  onSubmitHandler(event) {
    event.preventDefault();
    const sortFilterForms = document.querySelectorAll('facet-filters-form form');
    if (event.srcElement.className == 'mobile-facets__checkbox') {
      const searchParams = this.createSearchParams(event.target.closest('form'));
      this.onSubmitForm(searchParams, event);
    } else {
      const forms = [];
      const isMobile = event.target.closest('form').id === 'FacetFiltersFormMobile';

      sortFilterForms.forEach((form) => {
        if (!isMobile) {
          if (form.id === 'FacetSortForm' || form.id === 'FacetFiltersForm' || form.id === 'FacetSortDrawerForm') {
            const noJsElements = document.querySelectorAll('.no-js-list');
            noJsElements.forEach((el) => el.remove());
            forms.push(this.createSearchParams(form));
          }
        } else if (form.id === 'FacetFiltersFormMobile') {
          forms.push(this.createSearchParams(form));
        }
      });
      this.onSubmitForm(forms.join('&'), event);
    }
  }

  onActiveFilterClick(event) {
    event.preventDefault();
    FacetFiltersForm.toggleActiveFacets();
    const url =
      event.currentTarget.href.indexOf('?') == -1
        ? ''
        : event.currentTarget.href.slice(event.currentTarget.href.indexOf('?') + 1);
    FacetFiltersForm.renderPage(url);
  }
}

FacetFiltersForm.filterData = [];
FacetFiltersForm.searchParamsInitial = window.location.search.slice(1);
FacetFiltersForm.searchParamsPrev = window.location.search.slice(1);
customElements.define('facet-filters-form', FacetFiltersForm);
FacetFiltersForm.setListeners();

var PriceRange = class extends HTMLElement {
  connectedCallback() {

    this.rangeLowerBound = this.querySelector(".price-range__range-group input:first-child");
    this.rangeHigherBound = this.querySelector(".price-range__range-group input:last-child");

    this.textInputLowerBound = this.querySelector(".first-price-range-input input");
    this.textInputHigherBound = this.querySelector(".second-price-range-input input");

    const updateMinUI = () => {
      this.rangeLowerBound.parentElement.style.setProperty(
        "--range-min",
        `${(this.rangeLowerBound.value / this.rangeLowerBound.max) * 100}%`
      );
    };

    const updateMaxUI = () => {
      this.rangeHigherBound.parentElement.style.setProperty(
        "--range-max",
        `${(this.rangeHigherBound.value / this.rangeHigherBound.max) * 100}%`
      );
    };

    /* -------- TEXT INPUT LOWER -------- */
    this.textInputLowerBound.addEventListener("change", (e) => {
      let value = parseInt(e.target.value) || 0;

      value = Math.max(
        Math.min(value, parseInt(this.rangeHigherBound.value) - 1),
        parseInt(this.rangeLowerBound.min)
      );

      this.rangeLowerBound.value = value;
      this.textInputLowerBound.value = value;
      updateMinUI();
    });

    /* -------- TEXT INPUT HIGHER -------- */
    this.textInputHigherBound.addEventListener("change", (e) => {
      let value = parseInt(e.target.value) || 0;

      value = Math.min(
        Math.max(value, parseInt(this.rangeLowerBound.value) + 1),
        parseInt(this.rangeHigherBound.max)
      );

      this.rangeHigherBound.value = value;
      this.textInputHigherBound.value = value;
      updateMaxUI();
    });

    /* -------- RANGE LOWER -------- */
    this.rangeLowerBound.addEventListener("input", (e) => {
      let value = Math.min(
        parseInt(e.target.value),
        parseInt(this.rangeHigherBound.value) - 1
      );

      this.rangeLowerBound.value = value;
      this.textInputLowerBound.value = value;
      updateMinUI();
    });

    /* -------- RANGE HIGHER -------- */
    this.rangeHigherBound.addEventListener("input", (e) => {
      let value = Math.max(
        parseInt(e.target.value),
        parseInt(this.rangeLowerBound.value) + 1
      );

      this.rangeHigherBound.value = value;
      this.textInputHigherBound.value = value;
      updateMaxUI();
    });
  }
};
customElements.define("price-range", PriceRange);
/*
var PriceRange = class extends HTMLElement {
  connectedCallback() {
    this.rangeLowerBound = this.querySelector(".price-range__range-group input:first-child");
    this.rangeHigherBound = this.querySelector(".price-range__range-group input:last-child");
    this.textInputLowerBound = this.querySelector(".first-price-range-input input");
    this.textInputHigherBound = this.querySelector(".second-price-range-input input");
    this.textInputLowerBound.addEventListener("focus", () => this.textInputLowerBound.select());
    this.textInputHigherBound.addEventListener("focus", () => this.textInputHigherBound.select());
    this.textInputLowerBound.addEventListener("change", (event) => {
      let PriceValue = event.target.value
      PriceValue = Math.max(Math.min(parseInt(PriceValue), parseInt(this.textInputHigherBound.value || event.target.max) - 1), event.target.min);
      this.rangeLowerBound.value = PriceValue;
      this.rangeLowerBound.parentElement.style.setProperty("--range-min", `${parseInt(this.rangeLowerBound.value) / parseInt(this.rangeLowerBound.max) * 100}%`);
    });
    this.textInputHigherBound.addEventListener("change", (event) => {
      let PriceValue = event.target.value
      PriceValue = Math.min(Math.max(parseInt(PriceValue), parseInt(this.textInputLowerBound.value || event.target.min) + 1), event.target.max);
      this.rangeHigherBound.value = PriceValue;
      this.rangeHigherBound.parentElement.style.setProperty("--range-max", `${parseInt(this.rangeHigherBound.value) / parseInt(this.rangeHigherBound.max) * 100}%`);
    });
    this.rangeLowerBound.addEventListener("change", (event) => {
      let PriceValue = event.target.value
      this.textInputLowerBound.value = PriceValue;
      this.textInputLowerBound.dispatchEvent(new Event("change", { bubbles: true }));
    });
    this.rangeHigherBound.addEventListener("change", (event) => {
      let PriceValue = event.target.value
      this.textInputHigherBound.value = PriceValue;
      this.textInputHigherBound.dispatchEvent(new Event("change", { bubbles: true }));
    });
    this.rangeLowerBound.addEventListener("input", (event) => {
      let PriceValue = event.target.value
      PriceValue = Math.min(parseInt(PriceValue), parseInt(this.textInputHigherBound.value || event.target.max) - 1);
      event.target.parentElement.style.setProperty("--range-min", `${parseInt(PriceValue) / parseInt(event.target.max) * 100}%`);
      this.textInputLowerBound.value = PriceValue;
    });
    this.rangeHigherBound.addEventListener("input", (event) => {
      let PriceValue = event.target.value
      PriceValue = Math.max(parseInt(PriceValue), parseInt(this.textInputLowerBound.value || event.target.min) + 1);
      event.target.parentElement.style.setProperty("--range-max", `${parseInt(PriceValue) / parseInt(event.target.max) * 100}%`);
      this.textInputHigherBound.value = PriceValue;
    });
  }
};
customElements.define("price-range", PriceRange);
*/
class FacetRemove extends HTMLElement {
  constructor() {
    super();
    const facetLink = this.querySelector('a');
    facetLink.setAttribute('role', 'button');
    facetLink.addEventListener('click', this.closeFilter.bind(this));
    facetLink.addEventListener('keyup', (event) => {
      event.preventDefault();
      if (event.code.toUpperCase() === 'SPACE') this.closeFilter(event);
    });
  }

  closeFilter(event) {
    event.preventDefault();
    const form = this.closest('facet-filters-form') || document.querySelector('facet-filters-form');
    form.onActiveFilterClick(event);
  }
}

customElements.define('facet-remove', FacetRemove);

class CustomTagFilters extends HTMLElement {
  constructor() {
    super();
    try {
      this.sectionId = this.getAttribute('data-section-id');
      if (!this.sectionId) throw new Error('Missing data-section-id attribute');
      
      this.filterButtons = this.querySelectorAll('.tag-filters-list .tag-filter-item');
      if (!this.filterButtons.length) throw new Error('No filter buttons found');
      
      this.mobileFacetsContainer = document.querySelector(`.mobile-facets-${this.sectionId}`);
      this.desktopFacetsContainer = document.querySelector(`.desktop-facets-${this.sectionId}`);
      if (!this.mobileFacetsContainer || !this.desktopFacetsContainer) {
        throw new Error('Facets container not found');
      }
      this.setActiveFilterOnLoad(); // Set the active filter based on the URL
      this.initialize();
    } catch (error) {
      console.error('CustomTagFilters Initialization Error:', error.message);
    }
  }

  setActiveFilterOnLoad() {
    try {
      const url = new URL(window.location.href);
      const filterTag = url.searchParams.get('filter.p.tag');
  
      if (filterTag) {
        let activeSet = false;
        const normalizedFilterTag = filterTag.toLowerCase(); // Convert to lowercase
  
        this.filterButtons.forEach(button => {
          const tagName = button.getAttribute('data-filter-tag-name')?.toLowerCase(); // Convert to lowercase
          if (tagName === normalizedFilterTag) {
            button.classList.add('active-filter');
            activeSet = true;
          } else {
            button.classList.remove('active-filter');
          }
        });
  
        // If no matching tag is found, activate the first tab
        if (!activeSet && this.filterButtons.length > 0) {
          this.filterButtons[0].classList.add('active-filter');
        }
      } else {
        // If no `filter.p.tag` is found in the URL, keep the first tab active
        if (this.filterButtons.length > 0) {
          this.filterButtons[0].classList.add('active-filter');
        }
      }
    } catch (error) {
      console.error('Error setting active filter on load:', error.message);
    }
  }
  

  initialize() {
    this.filterButtons.forEach(eachButton => {
      eachButton.addEventListener('click', () => {
        try {
          this.filterButtons.forEach(button => button.classList.remove('active-filter'));
          eachButton.classList.add('active-filter');
          
          if (!eachButton.hasAttribute('data-filter-tag-name')) {
            throw new Error('Button missing data-filter-tag-name attribute');
          }
          
          const tagName = eachButton.getAttribute('data-filter-tag-name');
          const facetsContainer = window.innerWidth > 750 ? this.desktopFacetsContainer : this.mobileFacetsContainer;
          const detailsContainer = facetsContainer?.querySelector('.mobile-facets__details-more-filters');
          
          if (!detailsContainer) {
            throw new Error('Details container not found');
          }
          
          const inputEle = detailsContainer.querySelector(`input[data-filter-value="${tagName}"]`);
          if (!inputEle) {
            throw new Error(`Input element with data-filter-value="${tagName}" not found`);
          }
          
          const inputEleValue = inputEle.value;
          this.updateTagFilters(inputEleValue, inputEle);
        } catch (error) {
          console.error('Error handling filter button click:', error.message);
        }
      });
    });
  }

  updateTagFilters(newTag) {
    try {
      if (!newTag) throw new Error('New tag value is empty');
      if (!window.URL || !window.FacetFiltersForm) {
        throw new Error('Required global objects are missing');
      }
      
      const url = new URL(window.location.href);
      const tagKeys = [];
      
      url.searchParams.forEach((value, key) => {
        if (key.startsWith('filter.p.tag')) {
          tagKeys.push(key);
        }
      });
      
      tagKeys.forEach(key => url.searchParams.delete(key));
      url.searchParams.append('filter.p.tag', newTag);
      const newQueryString = url.searchParams.toString();
      
      if (typeof FacetFiltersForm.renderPage !== 'function') {
        throw new Error('FacetFiltersForm.renderPage is not a function');
      }
      
      FacetFiltersForm.renderPage(newQueryString);
    } catch (error) {
      console.error('Error updating tag filters:', error.message);
    }
  }
}

customElements.define('custom-tag-filters', CustomTagFilters);
