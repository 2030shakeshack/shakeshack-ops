class HeroBanner extends Carousel {
  constructor() {
    super();
    this.videoPosters = this.querySelectorAll('.deferred-media__poster-button');
    this.showCutomControls = this.getAttribute('data-show-custom-controls') === 'true';
    this.controlsOverlayContainers = this.querySelectorAll('.video-controls-overlay-container');
    if (this.videoPosters.length === 0) return;
    this.initialize();
  }

  initialize() {
    this.allSlides = this.carousel.Components.Elements.list.children;
    this.isMobileView = window.innerWidth < 750;
    if (this.showCutomControls){
      this.controlsOverlayContainers.forEach(container => {      
        const leftOverlay = container.querySelector('.overlay-left');
        const rightOverlay = container.querySelector('.overlay-right');
        leftOverlay.addEventListener('dblclick', this.skipBackward.bind(this));
        rightOverlay.addEventListener('dblclick', this.skipForward.bind(this));
        container.addEventListener("click", this.toggleVideoPlayPause.bind(this));
      });
    }
    this.carousel.on("moved", (newIndex) => this.handleVideoPlayback(newIndex));
    this.videoPosters.forEach((poster, index) => {
      poster.addEventListener("click", this.loadContent.bind(this));
      if(index === 0){
        poster?.click();
      }
    });
    this.handleInitialVideoLoad();
  }

  toggleVideoPlayPause(event){
    const videoEle = event.target?.closest('.video-section__media');
    const video = videoEle.querySelector("video");
    const pauseIcon = videoEle.querySelector(".toggle-play-pause-button");

    if (video) {
      if (video.paused) {
        video.play();
        pauseIcon?.classList.add("hidden");
      } else {
        video.pause();
        pauseIcon?.classList.remove("hidden");
      }
    }
  }

  skipForward(event) {
    event.stopPropagation();
    const videoSection = event.target?.closest('.video-section');
    const videoSpeed = videoSection?.dataset?.videoSpeed || 5;
    const container = event.currentTarget?.closest(".video-section__media");
    const video = container?.querySelector("video");
    const forwardIcon = container?.querySelector(".toggle-fast-forward-icon");

    if (video) {
      video.currentTime = Math.min(video.duration, video.currentTime + parseInt(videoSpeed));
      if (forwardIcon) {
        forwardIcon.classList.remove("hide-button");
        setTimeout(() => forwardIcon.classList.add("hide-button"), 1000);
      }
    }
  }

  skipBackward(event) {
    event.stopPropagation();
    const videoSection = event.target?.closest('.video-section');
    const videoSpeed = videoSection?.dataset?.videoSpeed || 5;
    const container = event.currentTarget.closest(".video-section__media");
    const video = container?.querySelector("video");
    const backwardIcon = container?.querySelector(".toggle-fast-backward-icon");

    if (video) {
      video.currentTime = Math.max(0, video.currentTime - parseInt(videoSpeed));
      if (backwardIcon) {
        backwardIcon.classList.remove("hide-button");
        setTimeout(() => backwardIcon.classList.add("hide-button"), 1000);
      }
    }
  }

  handleInitialVideoLoad() {
    try {
      const initialSlide = this.allSlides[this.carousel.index];
      if (!initialSlide) throw new Error("Initial slide not found.");
      
      const initialVideo = initialSlide.querySelector(`.video-section__media.${this.isMobileView ? "mobile-video" : "desktop-video"}`);
      
      if (initialVideo && initialVideo.dataset.autoplay === "true" && !initialVideo.getAttribute("loaded")) {
        this.loadContent(null, true, initialVideo);
      }
    } catch (error) {
      console.error("Error loading initial video:", error);
    }
  }

  handleVideoPlayback(newIndex) {
    try {
      const currentSlide = this.allSlides[newIndex];
      if (!currentSlide) throw new Error(`Slide at index ${newIndex} not found.`);
      
      const currentVideo = currentSlide.querySelector(`.video-section__media.${this.isMobileView ? "mobile-video" : "desktop-video"}`);
      
      if (currentVideo && currentVideo.dataset.autoplay === "true" && !currentVideo.getAttribute("loaded")) {
        this.loadContent(null, true, currentVideo);
      }
      
      this.toggleVideoPlayback(newIndex);
    } catch (error) {
      console.error("Error handling video playback:", error);
    }
  }

  toggleVideoPlayback(activeIndex) {
    Array.from(this.allSlides).forEach((slide, index) => {
      const videoElements = slide.querySelectorAll(".video-section__media video");
      if (!videoElements.length) return;
      
      videoElements.forEach((video) => {
        if (index === activeIndex) {
          video.play().catch(err => console.error("Error playing video:", err));
        } else {
          video.pause();
        }
      });
    });
  }

  loadContent(event, focus = true, videoElement = null) {
    try {
      if (typeof window.pauseAllMedia === "function") {
        window.pauseAllMedia();
      }
      
      const targetVideoContainer = event?.target.closest(".video-section__media") || videoElement;
      if (!targetVideoContainer || targetVideoContainer.getAttribute("loaded")) return;
      
      const templateElement = targetVideoContainer.querySelector("template");
      if (!templateElement) throw new Error("Template not found in video container.");
      
      const content = templateElement.content.firstElementChild.cloneNode(true);
      targetVideoContainer.setAttribute("loaded", "true");
      const deferredMedia = targetVideoContainer.appendChild(content);
      
      if (deferredMedia) {
        deferredMedia.play().catch(err => console.error("Error playing deferred video:", err));
      }
    } catch (error) {
      console.error("Error loading video content:", error);
    }
  }

  disconnectedCallback() {
    this.videoPosters.forEach((poster) => {
      poster.removeEventListener("click", this.loadContent.bind(this));
    });
  }
}

customElements.define("hero-banner", HeroBanner);