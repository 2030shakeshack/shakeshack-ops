if (!customElements.get('wf-hang-tag')) {
  customElements.define('wf-hang-tag', class extends HTMLElement {
    connectedCallback() {
      if (this.events) return;

      this.host = this.closest('[data-wfht-host]');
      this.card = this.querySelector('.wfht__card');
      if (!this.host || !this.card) return;

      this.events = new AbortController();
      const options = { signal: this.events.signal };
      this.motion = matchMedia('(prefers-reduced-motion: reduce)');
      this.motion.addEventListener('change', () => this.configureMotion(), options);
      this.card.addEventListener('animationend', (event) => {
        if (event.animationName === 'wfht-turn' && this.classList.contains('is-playing')) this.reveal();
      }, options);
      this.card.addEventListener('pointermove', (event) => this.moveSheen(event), options);
      this.card.addEventListener('pointerleave', () => this.clearSheen(), options);
      this.card.addEventListener('click', () => this.flip(), options);
      this.configureMotion();
    }

    disconnectedCallback() {
      this.events?.abort();
      this.events = null;
      this.observer?.disconnect();
      clearTimeout(this.flipTimer);
    }

    configureMotion() {
      this.observer?.disconnect();
      clearTimeout(this.flipTimer);
      this.classList.remove('is-waiting', 'is-playing', 'is-crest');
      this.clearSheen();
      this.card.disabled = this.motion.matches;
      if (this.motion.matches || this.revealed || !('IntersectionObserver' in window)) return;

      this.card.disabled = true;
      this.classList.add('is-waiting');
      const threshold = Math.min(.35, window.innerHeight * .8 / Math.max(1, this.host.offsetHeight));
      this.observer = new IntersectionObserver(([entry]) => {
        if (!entry.isIntersecting || entry.intersectionRatio < threshold) return;
        this.observer.disconnect();
        this.classList.replace('is-waiting', 'is-playing');
      }, { threshold });
      this.observer.observe(this.host);
    }

    reveal() {
      this.classList.remove('is-playing');
      this.revealed = true;
      this.card.disabled = this.motion.matches;
      if (this.motion.matches) return;

      this.host.querySelectorAll('[data-wfht-badge]').forEach((badge, index) => {
        badge.animate(
          [{ filter: 'brightness(1)' }, { filter: 'brightness(1.13)' }, { filter: 'brightness(1)' }],
          { duration: 550, delay: index * 100, easing: 'ease-in-out' }
        );
      });
    }

    moveSheen(event) {
      if (event.pointerType !== 'mouse' || this.card.disabled) return;
      const bounds = this.getBoundingClientRect();
      const x = Math.max(0, Math.min(1, (event.clientX - bounds.left) / bounds.width));
      this.style.setProperty('--wfht-sheen', `${20 + x * 60}%`);
    }

    clearSheen() {
      this.style.removeProperty('--wfht-sheen');
    }

    flip() {
      clearTimeout(this.flipTimer);
      if (!this.classList.toggle('is-crest')) return;
      this.flipTimer = setTimeout(() => this.classList.remove('is-crest'), 2200);
    }
  });
}
