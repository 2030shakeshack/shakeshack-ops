const initializeTechitGalleryDots = (scope = document) => {
  scope.querySelectorAll('media-gallery').forEach((gallery) => {
    if (gallery.dataset.techitGalleryDotsInitialized) return;
    const viewer = gallery.querySelector('[id^="GalleryViewer"]');
    const dots = gallery.querySelectorAll('[data-techit-gallery-target]');
    if (!viewer || dots.length === 0) return;

    const updateDots = (mediaId) => {
      dots.forEach((dot) => {
        if (dot.dataset.techitGalleryTarget === mediaId) {
          dot.setAttribute('aria-current', 'true');
        } else {
          dot.removeAttribute('aria-current');
        }
      });
    };

    gallery.addEventListener('click', (event) => {
      const dot = event.target.closest('[data-techit-gallery-target]');
      if (!dot) return;

      const thumbnail = Array.from(gallery.querySelectorAll('[data-target]')).find(
        (item) => item.dataset.target === dot.dataset.techitGalleryTarget
      );
      thumbnail?.querySelector('button')?.click();
      updateDots(dot.dataset.techitGalleryTarget);
    });

    viewer.addEventListener('slideChanged', (event) => {
      updateDots(event.detail.currentElement.dataset.mediaId);
    });

    gallery.dataset.techitGalleryDotsInitialized = 'true';
  });
};

initializeTechitGalleryDots();
document.addEventListener('shopify:section:load', (event) => initializeTechitGalleryDots(event.target));