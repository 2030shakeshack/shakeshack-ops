if (!customElements.get('sale-collection-tabs')) {
  class SaleCollectionTabs extends HTMLElement {
    constructor() {
      super();
      this.sectionId = this.dataset.sectionId;
      this.mobileLayout = this.dataset.mobileLayout || 'carousel';
      this.cache = new Map();
      this.splideInstance = null;
      this.init();
    }

    init() {
      this.mainSection = document.querySelector(`.sale-collection-tabs-${this.sectionId}`);
      if (!this.mainSection) return;

      this.shimmerContainer = this.mainSection.querySelector('.sale-tabs-shimmer');
      this.listContainer = this.querySelector('.sale-products-container');
      this.viewAllBtn = this.mainSection.querySelector('.sale-tabs-view-all');

      // Pre-cache initial server-rendered collection
      const initialTab = this.mainSection.querySelector('.sale-sub-tab.active');
      if (initialTab && initialTab.dataset.collectionHandle && this.listContainer) {
        this.cache.set(initialTab.dataset.collectionHandle, this.listContainer.innerHTML);
      }

      this.bindEvents();
      this.initSplide();
    }

    initSplide() {
      // Only initialize Splide if mobile layout is carousel and screen < 750px
      if (this.mobileLayout !== 'carousel') return;
      if (typeof Splide === 'undefined') return;

      const splideEl = this.querySelector('.splide');
      if (!splideEl) return;

      try {
        if (this.splideInstance) {
          this.splideInstance.destroy(true);
        }

        const isRtl = this.dataset.direction === 'rtl';
        const mobilePerPage = parseInt(this.dataset.mobilePerPage, 10) || 2;
        const gapMobile = this.dataset.gapMobile || '0.8rem';

        this.splideInstance = new Splide(splideEl, {
          type: 'slide',
          perPage: mobilePerPage,
          perMove: 1,
          gap: gapMobile,
          arrows: this.dataset.showArrows === 'true',
          pagination: this.dataset.showDots === 'true',
          direction: isRtl ? 'rtl' : 'ltr',
          mediaQuery: 'min',
          breakpoints: {
            750: {
              destroy: true,
            },
          },
        });

        this.splideInstance.mount();
      } catch (err) {
        console.warn('Splide init error:', err);
      }
    }

    bindEvents() {
      const tabsContainer = this.mainSection.querySelector('.sale-sub-tabs-bar');
      if (tabsContainer) {
        tabsContainer.addEventListener('click', (e) => {
          const tabBtn = e.target.closest('.sale-sub-tab');
          if (!tabBtn) return;
          this.handleTabClick(tabBtn);
        });
      }
    }

    handleTabClick(tabBtn) {
      if (tabBtn.classList.contains('active')) return;

      // Update tab active states
      this.mainSection.querySelectorAll('.sale-sub-tab').forEach((tab) => {
        const isActive = tab === tabBtn;
        tab.classList.toggle('active', isActive);
        tab.setAttribute('aria-selected', isActive ? 'true' : 'false');
      });

      this.loadCollection(tabBtn);
    }

    async loadCollection(tabBtn) {
      const collectionHandle = tabBtn.dataset.collectionHandle;
      const collectionUrl = tabBtn.dataset.collectionUrl || (collectionHandle ? `/collections/${collectionHandle}` : '');
      const tabTitle = tabBtn.dataset.tabTitle || tabBtn.textContent.trim();

      // Update View All button
      if (this.viewAllBtn) {
        if (collectionUrl) {
          this.viewAllBtn.href = collectionUrl;
          const textPrefix = this.viewAllBtn.dataset.textPrefix || 'VIEW ALL';
          const labelSpan = this.viewAllBtn.querySelector('.view-all-label');
          if (labelSpan) {
            labelSpan.textContent = `${textPrefix} ${tabTitle}`;
          }
          this.viewAllBtn.classList.remove('hidden');
        } else {
          this.viewAllBtn.classList.add('hidden');
        }
      }

      if (!collectionHandle) {
        if (this.listContainer) this.listContainer.innerHTML = '';
        return;
      }

      // Check client cache
      if (this.cache.has(collectionHandle)) {
        this.renderProducts(this.cache.get(collectionHandle));
        return;
      }

      // Show shimmer loader
      if (this.shimmerContainer) this.shimmerContainer.classList.remove('hidden');
      if (this.listContainer) this.listContainer.classList.add('hidden');

      try {
        const pathMatch = window.location.pathname.match(/^\/([a-zA-Z]{2}(-[a-zA-Z]{2})?)(?=\/|$)/);
        const langPrefix = pathMatch ? `/${pathMatch[1]}` : '';
        const url = `${langPrefix}/collections/${collectionHandle}?section_id=${this.sectionId}`;

        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP error ${response.status}`);
        const text = await response.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(text, 'text/html');
        const content = doc.querySelector('[data-ajax-products]');
        const html = content ? content.innerHTML.trim() : '';

        this.cache.set(collectionHandle, html);
        this.renderProducts(html);
      } catch (err) {
        console.error('Error loading collection tab products:', err);
        if (this.shimmerContainer) this.shimmerContainer.classList.add('hidden');
        if (this.listContainer) this.listContainer.classList.remove('hidden');
      }
    }

    renderProducts(html) {
      if (!this.listContainer) return;
      if (this.shimmerContainer) this.shimmerContainer.classList.add('hidden');
      this.listContainer.classList.remove('hidden');

      this.listContainer.innerHTML = html;

      // Re-init or refresh Splide if mobile carousel
      if (this.mobileLayout === 'carousel') {
        this.initSplide();
      }
    }
  }

  customElements.define('sale-collection-tabs', SaleCollectionTabs);
}
