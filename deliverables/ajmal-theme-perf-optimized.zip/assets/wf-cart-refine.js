/* wf-cart-refine.js — Tech It 11-Nov: small White Friday touches on the existing cart drawer.
   Adds: offer row on paired lines, "Add 1 more" on single eligible bottles, a note on Tawziyat lines,
   the offer badge on suggestion cards, "You save" in the footer, and a soft shine + rolling price
   when a pair completes. Layout, widths and spacing of the drawer are left as they are. */
(() => {
  const drawer = document.querySelector('cart-drawer');
  if (!drawer || !('MutationObserver' in window)) return;

  const isEmployee = drawer.hasAttribute('data-employee-customer');
  const ar = (document.documentElement.lang || '').toLowerCase().startsWith('ar');
  const T = ar
    ? { offer: 'خصم 50% على الثانية', more: 'أضف قطعة أخرى بخصم 50%', not: 'غير مشمول بعرض الجمعة البيضاء', save: 'وفّرت' }
    : { offer: '2nd at 50% off', more: 'Add 1 more, get it at 50% off', not: 'Not part of White Friday', save: 'You save' };
  const OFFER_TITLE = /white friday|50\s*%\s*off/i;   // the pair discount names its line "Sale : 50% OFF"
  const EXCLUDED = /taw[iy]?z|tawis|توزيع/i;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const money = (c) => (c / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  let observer, timer = 0, running = false, pending = false;
  const prevQty = new Map();      // variant id -> total quantity last seen (the discount splits a pair into two lines)
  let prevTotal = null;

  const WF_IN = ['mjmw-lmsk-2', 'misk-collection-new'], WF_OUT = ['saif-al-hind-new', 'saif-al-hind-new-employee'];   // keep in step with snippets/wf-offer-override.liquid
  const excluded = (item) => WF_OUT.includes(item.handle) || (!WF_IN.includes(item.handle) && (EXCLUDED.test(item.product_type || '') || EXCLUDED.test(item.product_title || '') || EXCLUDED.test(item.title || '')));
  const offerOn = (item) => (item.line_level_discount_allocations || []).some((a) => OFFER_TITLE.test(a.discount_application?.title || ''));
  const eligible = (item) => !excluded(item) && item.final_price > 0 && !item.gift_card && !(item.properties && (item.properties._freebie || item.properties._free));

  // number inside an element that also holds a currency icon: tween its text node
  const roll = (el, from, to) => {
    if (!el || from == null || from === to || reduced) return;
    const node = [...el.childNodes].reverse().find((n) => n.nodeType === 3 && /\d/.test(n.nodeValue));
    if (!node) return;
    const lead = node.nodeValue.match(/^\s*/)[0], tail = node.nodeValue.match(/\s*$/)[0];
    const t0 = performance.now(), dur = 700;
    const step = (now) => {
      const p = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      node.nodeValue = lead + money(Math.round(from + (to - from) * e)) + tail;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  const decorate = (cart) => {
    const lines = [...drawer.querySelectorAll('.cart--item')];
    const totals = new Map();
    cart.items.forEach((item) => totals.set(String(item.variant_id), (totals.get(String(item.variant_id)) || 0) + item.quantity));
    const linked = new Set();
    cart.items.forEach((item, i) => {
      const line = drawer.querySelector(`#CartDrawer-Item-${i + 1}`) || lines[i];
      if (!line) return;
      const id = String(item.variant_id);
      const total = totals.get(id);
      const mid = line.querySelector('.items-mid') || line.querySelector('.item-details');

      // offer row: restyle the discount the cart already lists
      const paired = offerOn(item);
      line.querySelectorAll('.discounts__discount').forEach((li) => {
        if (!OFFER_TITLE.test(li.textContent) || li.classList.contains('wf-row')) return;
        li.classList.add('wf-row');
        const text = [...li.childNodes].reverse().find((n) => n.nodeType === 3 && n.nodeValue.trim());
        if (text) text.nodeValue = ' ' + T.offer;
      });

      // odd number of an eligible bottle: one tap adds the next one (shown once per product)
      line.querySelector('.wf-more')?.remove();
      line.querySelector('.wf-not')?.remove();
      if (excluded(item)) {
        mid?.insertAdjacentHTML('beforeend', `<span class="wf-not">${T.not}</span>`);
      } else if (!isEmployee && eligible(item) && !paired && total % 2 === 1 && !linked.has(id)) {
        const plus = [...line.querySelectorAll('quantity-input button')].pop();
        if (plus && !plus.disabled && !plus.classList.contains('disabled')) {
          linked.add(id);
          const b = document.createElement('button');
          b.type = 'button';
          b.className = 'wf-more';
          b.textContent = T.more;
          b.addEventListener('click', () => plus.click());
          mid?.append(b);
        }
      }

      // pair just completed: shine on the discounted line
      const before = prevQty.get(id);
      if (paired && before != null && Math.floor(total / 2) > Math.floor(before / 2)) {
        line.classList.remove('wf-just');
        void line.offsetWidth;
        line.classList.add('wf-just');
      }
    });
    totals.forEach((q, id) => prevQty.set(id, q));
    [...prevQty.keys()].forEach((id) => { if (!totals.has(id)) prevQty.delete(id); });

    // footer: "You save" replaces the struck original total
    const foot = drawer.querySelector('.drawer__footer');
    const box = (s) => (s.parentElement.tagName === 'P' ? s.parentElement.parentElement : s.parentElement);
    const struck = foot && [...foot.querySelectorAll('s')].find((s) => !s.closest('.discounty-portal') && box(s).querySelector('strong'));
    if (struck) {
      const saved = cart.original_total_price - cart.total_price;
      let tag = struck.parentElement.querySelector('.wf-save');
      if (saved > 0) {
        const icon = struck.querySelector('svg')?.outerHTML || '';
        if (!tag) { tag = document.createElement('span'); tag.className = 'wf-save'; struck.before(tag); }
        tag.innerHTML = `${T.save} ${icon}<span>${money(saved)}</span>`;
        struck.hidden = true;
      } else {
        tag?.remove();
        struck.hidden = false;
      }
      const total = box(struck).querySelector('strong');
      const shown = total ? Math.round(parseFloat((total.textContent || '').replace(/[^\d.]/g, '')) * 100) : null;
      if (prevTotal != null && shown != null && drawer.querySelector('.cart--item.wf-just')) roll(total, prevTotal, shown);
      prevTotal = shown;
    }

    // suggestion cards: the site's offer badge, except Tawziyat
    drawer.querySelectorAll('[data-upsell-card]').forEach((card) => {
      if (isEmployee) return;
      if (card.querySelector('.wf-badge') || WF_OUT.includes(card.dataset.productHandle) || (!WF_IN.includes(card.dataset.productHandle) && (EXCLUDED.test(card.dataset.tags || '') || EXCLUDED.test(card.dataset.productHandle || '')))) return;
      card.querySelector('a.media, .product-card-image-cotainer')?.insertAdjacentHTML('beforeend', `<span class="wf-badge wf-badge--upsell" aria-hidden="true">${T.offer}</span>`);
    });
  };

  const run = async () => {
    if (running) return;
    running = true;
    try {
      const cart = await fetch(`${window.routes?.cart_url || '/cart'}.js`, { headers: { Accept: 'application/json' } }).then((r) => r.json());
      observer.disconnect();
      decorate(cart);
    } catch (e) { /* leave the drawer as rendered */ }
    observer.observe(drawer, { childList: true, subtree: true });
    running = false;
    if (pending) { pending = false; clearTimeout(timer); timer = setTimeout(run, 60); }
  };

  observer = new MutationObserver((records) => {
    if (running) { pending = true; return; }
    if (records.every((r) => [...r.addedNodes, ...r.removedNodes].every((n) => n.nodeType !== 1 || n.matches?.('.wf-more,.wf-not,.wf-save,.wf-badge--upsell')))) return;
    clearTimeout(timer);
    timer = setTimeout(run, 60);
  });
  observer.observe(drawer, { childList: true, subtree: true });
  run();
})();
