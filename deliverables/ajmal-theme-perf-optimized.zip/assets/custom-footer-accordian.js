class CustomCollapsible extends HTMLElement {
  constructor() {
    super();
    this.header = this.querySelector(".accordion-header");
    this.content = this.querySelector(".accordion-content");
    this.plusIcon = this.querySelector(".accordion-icon-plus");
    this.minusIcon = this.querySelector(".accordion-icon-minus");
    this.toggleCollapsible = this.toggleCollapsible.bind(this);
  }
  connectedCallback() {
    if (this.header){
      this.header.addEventListener("click", this.toggleCollapsible);
    }
  }
  disconnectedCallback() {
    if (this.header) {
      this.header.removeEventListener("click", this.toggleCollapsible);
    }
  }
  toggleCollapsible() {
    this.content.classList.toggle("hidden");
    const isExpanded = this.header.getAttribute("aria-expanded") === "true";
    this.header.setAttribute("aria-expanded", !isExpanded);
    this.plusIcon.classList.toggle("hidden");
    this.minusIcon.classList.toggle("hidden");
  }
}
customElements.define("custom-collapsible", CustomCollapsible);