(() => {
  class WhiteFridayPairCarousel extends HTMLElement {
    connectedCallback() {
      this.grid = this.querySelector('.wf-pair-grid');
      this.navigation = this.querySelector('.wf-pair-navigation');
      this.previous = this.querySelector('[data-wf-pair-previous]');
      this.next = this.querySelector('[data-wf-pair-next]');
      this.direction = getComputedStyle(this.grid).direction === 'rtl' ? -1 : 1;

      this.events = new AbortController();
      const { signal } = this.events;
      this.grid.addEventListener('scroll', () => this.update(), { passive: true, signal });
      this.previous.addEventListener('click', () => this.move(-1), { signal });
      this.next.addEventListener('click', () => this.move(1), { signal });
      this.resize = new ResizeObserver(() => this.update());
      this.resize.observe(this.grid);
      this.update();
    }

    update() {
      const { clientWidth, scrollWidth, scrollLeft } = this.grid;
      const max = scrollWidth - clientWidth;
      const position = Math.max(0, Math.min(max, scrollLeft * this.direction));
      this.navigation.hidden = max <= 1;
      this.toggleAttribute('data-overflow', max > 1);
      this.previous.setAttribute('aria-disabled', String(position <= 1));
      this.next.setAttribute('aria-disabled', String(max - position <= 1));
      if (max > 1) {
        this.style.setProperty('--wf-pair-progress', `${(clientWidth + position) / scrollWidth * 100}%`);
      }
    }

    move(direction) {
      const button = direction === 1 ? this.next : this.previous;
      if (button.getAttribute('aria-disabled') === 'true') return;

      const gap = parseFloat(getComputedStyle(this.grid).columnGap);
      const step = this.grid.firstElementChild.getBoundingClientRect().width + gap;
      const position = this.grid.scrollLeft * this.direction;
      const index = direction === 1 ? Math.floor((position + 1) / step) : Math.ceil((position - 1) / step);
      const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
      this.grid.scrollTo({ left: (index + direction) * step * this.direction, behavior: reducedMotion ? 'instant' : 'smooth' });
    }

    disconnectedCallback() {
      this.events.abort();
      this.resize.disconnect();
    }
  }
  if (!customElements.get('wf-pair-carousel')) customElements.define('wf-pair-carousel', WhiteFridayPairCarousel);

  class WhiteFridayQuantity extends HTMLElement {
    connectedCallback() {
      this.form = this.closest('form');
      this.productForm = this.closest('product-form');
      this.group = this.querySelector('[data-wf-limit]');
      if (!this.form || !this.group) return;

      this.controller = new AbortController();
      const { signal } = this.controller;
      this.sticky = this.querySelector('[data-wf-sticky]');
      this.submit = this.form.querySelector('button[name="add"]');
      this.field = this.form.elements.namedItem('quantity');
      this.variant = this.form.elements.namedItem('id');
      if (!this.field || !this.variant || !this.submit) return;

      this.group.addEventListener('click', (event) => {
        const button = event.target.closest('[data-wf-qty]');
        if (!button || button.disabled) return;
        this.touched = true;
        this.field.value = button.dataset.wfQty;
        this.field.dispatchEvent(new Event('change', { bubbles: true }));
        this.refresh();
      }, { signal });

      this.sticky.querySelector('[data-wf-sticky-add]').addEventListener('click', () => {
        if (!this.submit.disabled && this.submit.getAttribute('aria-disabled') !== 'true') this.submit.click();
      }, { signal });

      this.field.addEventListener('change', () => {
        if (!this.settingDefault) this.touched = true;
        this.refresh();
      }, { signal });
      if (typeof subscribe === 'function' && typeof PUB_SUB_EVENTS !== 'undefined') {
        this.quantitySubscription = subscribe(PUB_SUB_EVENTS.quantityUpdate, () => this.refresh());
      }

      this.mobile = window.matchMedia('(max-width: 749px)');
      const queueStickyUpdate = () => {
        if (this.stickyFrame) return;
        this.stickyFrame = requestAnimationFrame(() => {
          this.stickyFrame = 0;
          this.updateSticky();
        });
      };
      window.addEventListener('scroll', queueStickyUpdate, { passive: true, signal });
      window.addEventListener('resize', queueStickyUpdate, { signal });
      this.submitObserver = new MutationObserver(() => this.updateSticky());
      this.submitObserver.observe(this.submit, { attributes: true, attributeFilter: ['disabled','aria-disabled'] });
      this.refresh();
    }

    refresh() {
      const available = Math.max(0, Number(this.group.dataset.wfLimit) - Number(this.field.dataset.cartQuantity || 0));
      const limit = this.field.max && Number(this.field.max) > 0 ? Math.min(available, Number(this.field.max)) : available;
      const quantity = Number(this.field.value || 1);
      const enabled = this.dataset.variant === this.variant.value && limit >= 2 && (quantity === 1 || quantity === 2);
      this.hidden = !enabled;
      this.toggleAttribute('data-wf-active', enabled);

      // Pair is the default choice, unless the shopper already has an odd number in the cart
      // (then one more completes their pair) or has picked a quantity themselves.
      if (enabled && !this.touched && !this.defaulted) {
        this.defaulted = true;
        const inCart = Number(this.field.dataset.cartQuantity || 0);
        if (inCart % 2 === 0 && quantity === 1) {
          this.settingDefault = true;
          this.field.value = '2';
          this.field.dispatchEvent(new Event('change', { bubbles: true }));
          this.settingDefault = false;
          if (Number(this.field.value) === 2) return;
        }
      }

      for (const button of this.group.querySelectorAll('[data-wf-qty]')) {
        button.disabled = Number(button.dataset.wfQty) > limit;
        const selected = Number(button.dataset.wfQty) === quantity;
        button.setAttribute('aria-pressed', String(selected));
        if (selected) {
          this.sticky.querySelector('[data-wf-sticky-selection]').textContent =
            button.querySelector('[data-wf-option-name]').textContent + ' · ' + button.querySelector('strong').textContent.trim();
        }
      }
      this.applyLabel(enabled ? quantity : 0);
      this.updateSticky();
    }

    // "Add pair · 93.15" on the main and sticky buttons, so the total being added is never a surprise.
    // Only text we wrote is ever restored, so theme states such as "Sold out" are left alone.
    applyLabel(quantity) {
      const template = this.querySelector(`template[data-wf-label="${quantity}"]`);
      const usable = Boolean(template) && !this.submit.disabled && this.submit.getAttribute('aria-disabled') !== 'true';
      const targets = [this.submit.querySelector(':scope > span'), this.sticky.querySelector('[data-wf-sticky-add]')];
      for (const target of targets) {
        if (!target) continue;
        const ours = target.dataset.wfHtml !== undefined && target.innerHTML === target.dataset.wfHtml;
        if (usable) {
          if (!ours) target.dataset.wfOriginal = target.innerHTML;
          if (target.innerHTML !== template.innerHTML) target.innerHTML = template.innerHTML;
          target.dataset.wfHtml = target.innerHTML;
        } else if (ours) {
          target.innerHTML = target.dataset.wfOriginal;
          delete target.dataset.wfHtml;
          delete target.dataset.wfOriginal;
        }
      }
    }

    updateSticky() {
      this.sticky.hidden = this.hidden || !this.mobile.matches || this.submit.disabled || this.submit.getBoundingClientRect().bottom >= 0;
      this.sticky.querySelector('[data-wf-sticky-add]').disabled = this.submit.getAttribute('aria-disabled') === 'true';
    }

    disconnectedCallback() {
      this.controller?.abort();
      cancelAnimationFrame(this.stickyFrame);
      this.submitObserver?.disconnect();
      this.quantitySubscription?.();
    }
  }
  if (!customElements.get('white-friday-quantity')) customElements.define('white-friday-quantity', WhiteFridayQuantity);

  if (typeof subscribe === 'function' && typeof PUB_SUB_EVENTS !== 'undefined') {
    subscribe(PUB_SUB_EVENTS.variantChange, ({ data }) => {
      if (!data?.html) return;
      for (const current of document.querySelectorAll('white-friday-quantity')) {
        const next = data.html.querySelector(`white-friday-quantity[data-wf-quantity="${CSS.escape(current.dataset.wfQuantity)}"]`);
        if (next) current.replaceWith(next.cloneNode(true));
      }
    });
  }

  // Twin reveal: when a cart line becomes a pair and the cart really prices the 2nd unit at 50%,
  // a second bottle slides in behind the first and the 2nd unit's price strikes to half.
  // Purely decorative: it runs after the drawer has already rendered the confirmed prices.
  (() => {
    const drawer = document.querySelector('cart-drawer');
    if (!drawer || !('MutationObserver' in window)) return;
    const arabic = (document.documentElement.lang || '').toLowerCase().startsWith('ar');
    const label = arabic ? 'خصم 50٪ على الثانية' : '2nd at 50% off';
    const paired = new Map();
    let last = null;
    let timer = 0;
    const money = (cents) => (cents / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const lines = () => [...drawer.querySelectorAll('.cart--item')];
    const lineFor = (id) => lines().find((item) => item.querySelector(`input[data-quantity-variant-id="${CSS.escape(id)}"]`));
    const read = () => {
      const map = new Map();
      for (const item of lines()) {
        const input = item.querySelector('input[data-quantity-variant-id]');
        if (!input) continue;
        const id = input.dataset.quantityVariantId;
        map.set(id, (map.get(id) || 0) + Number(input.value || 0));
      }
      return map;
    };
    const decorate = (id, offer, play) => {
      const item = lineFor(id);
      if (!item || item.querySelector('.wf-twin-price')) return;
      const media = item.querySelector('.cart-item__media');
      const image = media?.querySelector('img');
      if (image) {
        const ghost = image.cloneNode(false);
        ghost.removeAttribute('id');
        ghost.removeAttribute('loading');
        ghost.className = 'wf-twin-ghost';
        ghost.alt = '';
        ghost.setAttribute('aria-hidden', 'true');
        media.classList.add('wf-twin-media');
        media.prepend(ghost);
      }
      const icon = item.querySelector('.product-price svg')?.outerHTML || '';
      const chip = document.createElement('p');
      chip.className = 'wf-twin-price';
      chip.innerHTML = `<span class="wf-twin-label">${label}</span> <s class="wf-money">${icon}${money(offer.unit)}</s> <strong class="wf-money">${icon}${money(offer.half)}</strong>`;
      const anchor = item.querySelector('.items-mid') || item.querySelector('.item-details');
      anchor?.append(chip);
      if (!play) return;
      const start = () => {
        item.classList.remove('wf-twin-play');
        void item.offsetWidth;
        item.classList.add('wf-twin-play');
      };
      if (drawer.classList.contains('active')) { start(); return; }
      const began = performance.now();
      const wait = () => {
        if (drawer.classList.contains('active')) setTimeout(start, 180);
        else if (performance.now() - began < 1500) setTimeout(wait, 50);
      };
      wait();
    };
    const check = async () => {
      const now = read();
      if (!last) { last = now; return; }
      const before = last;
      last = now;
      for (const id of [...paired.keys()]) if ((now.get(id) || 0) < 2) paired.delete(id);
      const crossed = [...now].filter(([id, quantity]) => Math.floor(quantity / 2) > Math.floor((before.get(id) || 0) / 2)).map(([id]) => id);
      for (const [id, offer] of paired) if (!crossed.includes(id)) decorate(id, offer, false);
      if (!crossed.length) return;
      let cart;
      try {
        cart = await fetch(`${window.routes?.cart_url || '/cart'}.js`, { headers: { Accept: 'application/json' } }).then((response) => response.json());
      } catch { return; }
      for (const id of crossed) {
        const items = cart.items.filter((line) => String(line.variant_id) === id);
        const quantity = items.reduce((sum, line) => sum + line.quantity, 0);
        if (quantity < 2 || !items.length) continue;
        const unit = Number(items[0].original_price || items[0].price);
        const off = Math.round(unit / 2);
        const saved = items.reduce((sum, line) => sum + (Number(line.original_line_price) - Number(line.final_line_price)), 0);
        const pairs = Math.floor(quantity / 2);
        // Only celebrate what the cart actually charges: the saving must equal 50% off one unit per pair.
        if (Math.abs(saved - pairs * off) > pairs * 2) continue;
        const offer = { unit, half: unit - off };
        paired.set(id, offer);
        decorate(id, offer, true);
      }
    };
    new MutationObserver(() => {
      clearTimeout(timer);
      timer = setTimeout(check, 30);
    }).observe(drawer, { childList: true, subtree: true });
    check();
    window.AjmalWhiteFridayTwin = { preview(id) { const item = lineFor(String(id)); if (!item) return false; const unit = Math.round(parseFloat((item.querySelector('.product-price')?.textContent || '').replace(/[^\d.]/g, '')) * 100 / Math.max(1, Number(item.querySelector('input[data-quantity-variant-id]')?.value || 1))) || 0; decorate(String(id), { unit, half: unit - Math.round(unit / 2) }, true); return true; } };
  })();

  const dialog = document.getElementById('WhiteFridayPairPrompt');
  if (!dialog || typeof dialog.showModal !== 'function') return;
  const add = dialog.querySelector('[data-wf-add]');
  const view = dialog.querySelector('[data-wf-view]');
  const keep = dialog.querySelector('[data-wf-close]');
  const error = dialog.querySelector('[data-wf-error]');
  const art = dialog.querySelector('[data-wf-art]');
  const images = art.querySelectorAll('[data-wf-image]');
  let pending;

  images[0].addEventListener('error', () => { art.hidden = true; });

  dialog.addEventListener('cancel', (event) => {
    if (add.disabled) event.preventDefault();
  });
  dialog.addEventListener('close', () => {
    const selection = pending;
    pending = undefined;
    if (!selection) return;
    if (selection.result.sections) {
      selection.form.cart.renderContents(selection.result, dialog.returnValue === 'cart');
    } else {
      location.assign(window.routes.cart_url);
    }
  });
  view.addEventListener('click', () => dialog.close('cart'));
  keep.addEventListener('click', () => dialog.close());

  add.addEventListener('click', async () => {
    if (!pending || add.disabled) return;
    add.disabled = view.disabled = keep.disabled = true;
    error.hidden = true;
    try {
      const body = new FormData();
      for (const [key, value] of pending.data.entries()) body.append(key, value);
      body.set('quantity', '1');
      const response = await fetch(window.routes.cart_add_url, {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json' },
        body,
      });
      const result = await response.json();
      if (!response.ok || result.status) {
        error.textContent = dialog.dataset.error;
        error.hidden = false;
        return;
      }
      pending.result = result;
      publish(PUB_SUB_EVENTS.cartUpdate, {
        source: 'product-form',
        productVariantId: body.get('id'),
        cartData: result,
      });
      dialog.close('cart');
    } catch {
      error.textContent = dialog.dataset.error;
      error.hidden = false;
    } finally {
      add.disabled = view.disabled = keep.disabled = false;
    }
  });

  window.AjmalWhiteFriday = {
    offerAfterAdd(form, data, result) {
      const offer = form.closest('[data-wf-card]')?.querySelector('[data-wf-offer]');
      if (!offer || pending || !result.sections || String(data.get('id')) !== offer.dataset.variant) return false;
      if (Number(data.get('quantity') || 1) !== 1 || !result.quantity || result.quantity % 2 === 0) return false;
      if (result.quantity >= Number(offer.dataset.limit)) return false;
      const freebie = window.freebieModalState || {};
      if (document.getElementById('FreebieModal') && !freebie.selected && !freebie.skip) return false;

      const name = result.product_title || result.title || '';
      const { unit, half, halfLabel, pair, each } = offer.dataset;
      const description = dialog.dataset.description.replace(/\[product\]|\[price\]/g, (token) =>
        token === '[product]' ? name : halfLabel
      );
      const content = { description, unit, half, total: pair, each, increase: `+${halfLabel}` };
      for (const [key, value] of Object.entries(content)) {
        dialog.querySelector(`[data-wf-${key}]`).textContent = value;
      }
      const imageUrl = offer.dataset.art || result.featured_image?.url || result.image;
      art.hidden = !imageUrl;
      if (imageUrl) images.forEach((image) => { image.src = imageUrl; });
      error.hidden = true;
      dialog.returnValue = '';
      try {
        dialog.showModal();
      } catch {
        return false;
      }
      pending = { form, data, result };
      return true;
    },
  };
})();
