class CartDrawer extends HTMLElement {
  constructor() {
    super();

    this.addEventListener('keyup', (evt) => evt.code === 'Escape' && this.close());
    this.querySelector('#CartDrawer-Overlay').addEventListener('click', this.close.bind(this));
    this.setHeaderCartIconAccessibility();
  }

  setHeaderCartIconAccessibility() {
    const cartLink = document.querySelector('#cart-icon-bubble');
    cartLink.setAttribute('role', 'button');
    cartLink.setAttribute('aria-haspopup', 'dialog');
    cartLink.addEventListener('click', (event) => {
      event.preventDefault();
      this.open(cartLink);
    });
    cartLink.addEventListener('keydown', (event) => {
      if (event.code.toUpperCase() === 'SPACE') {
        event.preventDefault();
        this.open(cartLink);
      }
    });
  }

  open(triggeredBy) {
    if (triggeredBy) this.setActiveElement(triggeredBy);
    const cartDrawerNote = this.querySelector('[id^="Details-"] summary');
    if (cartDrawerNote && !cartDrawerNote.hasAttribute('role')) this.setSummaryAccessibility(cartDrawerNote);
    // here the animation doesn't seem to always get triggered. A timeout seem to help
    setTimeout(() => {
      this.classList.add('animate', 'active');
    });

    this.addEventListener(
      'transitionend',
      () => {
        const containerToTrapFocusOn = this.classList.contains('is-empty')
          ? this.querySelector('.drawer__inner-empty')
          : document.getElementById('CartDrawer');
        const focusElement = this.querySelector('.drawer__inner') || this.querySelector('.drawer__close');
        trapFocus(containerToTrapFocusOn, focusElement);
      },
      { once: true }
    );

    document.body.classList.add('overflow-hidden');
  }

  close() {
    this.classList.remove('active');
    removeTrapFocus(this.activeElement);
    document.body.classList.remove('overflow-hidden');
  }

  setSummaryAccessibility(cartDrawerNote) {
    cartDrawerNote.setAttribute('role', 'button');
    cartDrawerNote.setAttribute('aria-expanded', 'false');

    if (cartDrawerNote.nextElementSibling.getAttribute('id')) {
      cartDrawerNote.setAttribute('aria-controls', cartDrawerNote.nextElementSibling.id);
    }

    cartDrawerNote.addEventListener('click', (event) => {
      event.currentTarget.setAttribute('aria-expanded', !event.currentTarget.closest('details').hasAttribute('open'));
    });

    cartDrawerNote.parentElement.addEventListener('keyup', onKeyUpEscape);
  }

  renderContents(parsedState, openAfterRender = true) {
    this.querySelector('.drawer__inner').classList.contains('is-empty') &&
      this.querySelector('.drawer__inner').classList.remove('is-empty');
    this.productId = parsedState.id || parsedState.items[0].id; //Or condition for frequently bought together products 
    this.getSectionsToRender().forEach((section) => {
      const sectionElement = section.selector
        ? document.querySelector(section.selector)
        : document.getElementById(section.id);
      sectionElement.innerHTML = this.getSectionInnerHTML(parsedState.sections[section.id], section.selector);
    });

    // Check if a freebie modal exists and no freebie has been selected yet.
    // If so, we should defer opening the drawer until the freebie flow completes.
    const freebieModal = document.getElementById('FreebieModal');
    const freebieState = window.freebieModalState || {};
    const freebieSelected = Boolean(freebieState.selected);
    const skipFreebie = Boolean(freebieState.skip);
    const shouldDeferOpen = Boolean(
      ((freebieModal && !freebieSelected) || freebieState.deferDrawerOpen) && !skipFreebie
    );

    // If we need to defer opening (freebie modal will open first), make sure
    // any server-returned HTML that already includes `active`/`animate` classes
    // or open attributes is reset so the cart drawer does not show immediately.
    if (shouldDeferOpen) {
      // Remove classes from this custom element itself
      this.classList.remove('active', 'animate');

      // Remove from common drawer nodes inserted into the section HTML
      const drawerNode = this.querySelector('.drawer') || this;
      drawerNode.classList.remove('active', 'animate');

      // Close any <details open> inserted in the template
      const openDetails = this.querySelectorAll('details[open]');
      openDetails.forEach((d) => d.removeAttribute('open'));

      // Ensure aria-expanded summaries are set to false
      const summaries = this.querySelectorAll('[id^="Details-"] summary');
      summaries.forEach((s) => s.setAttribute('aria-expanded', 'false'));
    }

    setTimeout(() => {
      const overlay = this.querySelector('#CartDrawer-Overlay');
      if (overlay) {
        overlay.addEventListener('click', this.close.bind(this));
      }

      // Apply freebie quantity controls restriction
      if (window.freebieModalState && window.freebieModalState.selected) {
        try {
          if (typeof window.disableFreebieQuantityControls === 'function') {
            window.disableFreebieQuantityControls();
          }
        } catch (e) {}
      }

      if (!openAfterRender) return;

      if (!shouldDeferOpen) {
        this.open();
        return;
      }

      // Defer opening the cart drawer until the freebie modal finishes.
      // Listen for common custom events or watch the freebieModalState being cleared.
      let checkInterval;
      const openDrawer = () => {
        this.open();
        window.removeEventListener('freebie:closed', openDrawer);
        window.removeEventListener('freebie:productSelected', openDrawer);
        window.removeEventListener('freebie:selection', openDrawer);
        if (checkInterval) clearInterval(checkInterval);
      };

      window.addEventListener('freebie:closed', openDrawer, { once: true });
      window.addEventListener('freebie:productSelected', openDrawer, { once: true });
      window.addEventListener('freebie:selection', openDrawer, { once: true });

      // Fallback: poll the freebieModalState flag in case the freebie flow doesn't dispatch events.
      checkInterval = setInterval(() => {
        const freebieModalExists = document.getElementById('FreebieModal') !== null;
        const freebieSelected = window.freebieModalState && window.freebieModalState.selected;
        
        // Open the drawer if:
        // 1. No freebie modal exists on the page, OR
        // 2. A freebie has been selected
        if (!freebieModalExists || freebieSelected) {
          openDrawer();
        }
      }, 250);
    });
  }

  getSectionInnerHTML(html, selector = '.shopify-section') {
    return new DOMParser().parseFromString(html, 'text/html').querySelector(selector).innerHTML;
  }

  getSectionsToRender() {
    return [
      {
        id: 'cart-drawer',
        selector: '#CartDrawer',
      },
      {
        id: 'cart-icon-bubble',
      },
    ];
  }

  getSectionDOM(html, selector = '.shopify-section') {
    return new DOMParser().parseFromString(html, 'text/html').querySelector(selector);
  }

  setActiveElement(element) {
    this.activeElement = element;
  }
}

customElements.define('cart-drawer', CartDrawer);

class CartDrawerItems extends CartItems {
  getSectionsToRender() {
    return [
      {
        id: 'CartDrawer',
        section: 'cart-drawer',
        selector: '.drawer__inner',
      },
      {
        id: 'cart-icon-bubble',
        section: 'cart-icon-bubble',
        selector: '.shopify-section',
      },
    ];
  }
}

customElements.define('cart-drawer-items', CartDrawerItems);
