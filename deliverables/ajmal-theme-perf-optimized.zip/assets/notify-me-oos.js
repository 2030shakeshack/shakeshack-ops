(function () {
  var initializedBlocks = new WeakSet();
  function init(block) {

  // Check if products storage has expired
  const productsExpiry = localStorage.getItem('productsExpiry');

  if (productsExpiry && Date.now() > Number(productsExpiry)) {
    localStorage.removeItem('products');
    localStorage.removeItem('productsExpiry');
  }

  const scriptUrl  = "https://script.google.com/macros/s/AKfycbxUAkNDVliNbrwR_grHOc8tEZVaBr9J6WkcW-ogtjTZzgNXmWUroTmodwl4-kcS0xPL/exec";

    /* Snippet can be rendered (and this script included) more than once per page */
    if (initializedBlocks.has(block)) return;
    initializedBlocks.add(block);

    var nmId         = block.dataset.nmBlock;
    var productTitle = block.dataset.nmProduct     || '';
    var productUrl   = block.dataset.nmUrl         || '';
    var phonePrefix  = block.dataset.nmPrefix      || '+966';
    var popupBtnText = block.dataset.nmPopupBtn    || 'Notify Me';

    var modalTemplate = block.nextElementSibling;
    var overlay = modalTemplate && modalTemplate.matches('template[data-nm-template]')
      ? modalTemplate.content.firstElementChild.cloneNode(true)
      : null;
    if (!overlay) {
      overlay = document.getElementById('nm-overlay-' + nmId);
    }
    document.querySelectorAll('[data-nm-overlay]').forEach(function (existing) {
      if (existing !== overlay && existing.id === 'nm-overlay-' + nmId) existing.remove();
    });
    if (overlay && overlay.parentNode !== document.body) document.body.appendChild(overlay);
    var formWrap   = document.getElementById('nm-form-wrap-' + nmId);
    var form       = document.getElementById('nm-form-'      + nmId);

    var emailErr   = document.getElementById('nm-email-err-' + nmId);
    var phoneInput = document.getElementById('nm-phone-'     + nmId);
    var submitBtn  = document.getElementById('nm-submit-'    + nmId);
    var notifyTitle = document.getElementById('nm-card-'+ nmId);
    var notifyBtn  = block.querySelector('button');
    var notifyBtnText = notifyBtn && (
      notifyBtn.querySelector('span:not([aria-hidden="true"])') || notifyBtn
    );
    var errEl      = document.getElementById('nm-err-'       + nmId);
    var tyEl       = document.getElementById('nm-ty-'        + nmId);
    var notifNum   = document.getElementById('nm-notif-num-' + nmId);
    var editBtn    = document.getElementById('nm-edit-btn-'  + nmId);
    var notifyBtns = block.querySelectorAll('[data-nm-open]');
    notifyBtns.forEach(function (btn) {
      btn.addEventListener('click', open);
    });

    const alertOnText = document.documentElement.lang.startsWith('ar') ? 'تنبيه عند التوفر' : 'Alert on'

    /* Move overlay to <body> so position:fixed is not trapped by transformed parents (e.g. sticky ATC bar) */
    if (overlay && overlay.parentNode !== document.body) document.body.appendChild(overlay);


    function updateNotifyButton() {
    var products = JSON.parse(localStorage.getItem('products') || '[]');

        if (products.includes(productTitle)) {
          if (notifyBtnText) {
            notifyBtnText.textContent = alertOnText;
          }
        }
    }

    

    updateNotifyButton();

    function open() {
      var customerPhone = '';
      if (typeof getCustomerPhone === 'function') {
        customerPhone = getCustomerPhone() || '';
      }
      

      const storedPhone = localStorage.getItem('phone');
      const phone = customerPhone || storedPhone;

      if (phone && phoneInput) phoneInput.value = phone;
      if (!overlay) return;
      overlay.hidden = false;
      overlay.setAttribute('aria-hidden', 'false');
      overlay.classList.add('nm-open');
      document.body.style.overflow = 'hidden';
      if (phoneInput) phoneInput.focus();
    }

    function close() {
      if (overlay) {
        overlay.classList.remove('nm-open');
        overlay.hidden = true;
        overlay.setAttribute('aria-hidden', 'true');
      }
      document.body.style.overflow = '';
      resetSheet();
      if (notifyBtn && notifyBtn.isConnected) notifyBtn.focus();
    }

    function showThanks() {
      formWrap.classList.add('nm-hidden');
      tyEl.classList.add('nm-show');
      submitBtn.disabled = false;
      submitBtn.textContent = popupBtnText;
      if (notifyBtnText) notifyBtnText.textContent = alertOnText;
    }

    function resetSheet() {
      tyEl && tyEl.classList.remove('nm-show');
      formWrap && formWrap.classList.remove('nm-hidden');
      form && form.reset();
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = popupBtnText;
      }
      errEl && errEl.classList.remove('nm-show');
      emailErr && emailErr.classList.remove('nm-show');
    }

    window['nmOosClose' + nmId] = close;

    overlay && overlay.addEventListener('click', function (e) {
      if (e.target === overlay) close();
    });

    overlay && overlay.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && overlay && overlay.classList.contains('nm-open')) close();
      if (e.key === 'Tab' && overlay.classList.contains('nm-open')) {
        var focusable = Array.from(overlay.querySelectorAll('button:not([disabled]), input:not([disabled]), a[href], [tabindex="0"]')).filter(function (el) { return el.getClientRects().length; });
        var first = focusable[0];
        var last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });

    editBtn && editBtn.addEventListener('click', function () {
      tyEl.classList.remove('nm-show');
      formWrap.classList.remove('nm-hidden');
      phoneInput && phoneInput.focus();
    });

    form && form.addEventListener('submit', function (e) {
      e.preventDefault();

      var phone = phoneInput ? phoneInput.value.trim() : '';


        // BLOCK EMPTY OR INVALID PHONE
        if (!phone || !/^\d{10}$/.test(phone)) {
          if (errEl) errEl.classList.add('nm-show');
          if (phoneInput) phoneInput.focus();

          console.log('Invalid phone - submission stopped');
          return;
        }
      errEl && errEl.classList.remove('nm-show');

      submitBtn.disabled = true;
      submitBtn.textContent = 'Submitting…';

      let currentArray = JSON.parse(localStorage.getItem('products') || '[]');

      //adding phone to local storage
      if (phone){
        localStorage.setItem("phone", phone);
      }
      if (!currentArray.includes(productTitle)) {
        currentArray.push(productTitle);
      }
      localStorage.setItem('products', JSON.stringify(currentArray));

      // Expire after 3 days
        localStorage.setItem(
          'productsExpiry',
          Date.now() + (3 * 24 * 60 * 60 * 1000)
        );
      const Products = localStorage.getItem('products');

      var displayPhone = phone ? (phonePrefix + ' ' + phone) : '';
      if (notifNum) notifNum.textContent = displayPhone || phonePrefix;

      if (!scriptUrl) { showThanks(); return; }

      var now = new Date();
      var formattedTimestamp = now.toLocaleDateString('en-GB') + ' ' + now.toLocaleTimeString('en-IN', { hour12: false });

      var params = new URLSearchParams({
        timestamp: formattedTimestamp,
        phone: phone,
        product: productTitle,
        url: productUrl
      });

      fetch(scriptUrl + '?' + params, { method: 'GET', mode: 'no-cors' })
        .then(showThanks).catch(showThanks);
    });

    overlay && overlay.addEventListener('transitionend', function () {
      if (!overlay.classList.contains('nm-open')) setTimeout(resetSheet, 300);
    });
  }

 document.querySelectorAll('[data-nm-block]').forEach(init);

  const observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      mutation.addedNodes.forEach(function (node) {
        if (node.nodeType !== 1) return;

        // If the added element itself is a notify block
        if (node.matches('[data-nm-block]')) {
          init(node);
        }

        // If notify blocks are inside the added element
        node.querySelectorAll &&
          node.querySelectorAll('[data-nm-block]').forEach(init);
      });
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  if (window.__nmOosGlobalBound) return;
  window.__nmOosGlobalBound = true;

  function findVariant(id) {
    var list = window.productData && window.productData.variants;
    if (!list) return null;
    for (var i = 0; i < list.length; i++) {
      if (String(list[i].id) === String(id)) return list[i];
    }
    return null;
  }

  /* Swap notify/buy panels on variant change — single global listener */
  function applyVariant(v) {
    if (!v) return;
    var isOos = !v.available || !!document.querySelector('[data-nm-force-oos]');
    document.querySelectorAll('.nm-notify-panel').forEach(function (p) {
      p.classList.toggle('nm-panel-hidden', !isOos);
    });
    document.querySelectorAll('.nm-buy-panel').forEach(function (p) {
      p.classList.toggle('nm-panel-hidden', isOos);
    });
    if (!isOos) {
      document.querySelectorAll('[data-nm-overlay]').forEach(function (o) {
        o.classList.remove('nm-open');
        o.hidden = true;
        o.setAttribute('aria-hidden', 'true');
      });
      document.body.style.overflow = '';
    }
  }

  document.addEventListener('variant:change', function (e) {
    applyVariant(e.detail && e.detail.variant);
  });

  /* Product form variant id input (main product) */
  document.addEventListener('change', function (e) {
    var t = e.target;
    if (!t || t.name !== 'id' || !t.closest('form[data-type="add-to-cart-form"]')) return;
    applyVariant(findVariant(t.value));
  });

  if (typeof subscribe === 'function' && typeof PUB_SUB_EVENTS !== 'undefined') {
    subscribe(PUB_SUB_EVENTS.variantChange, function (event) {
      var v = event && event.data && event.data.variant;
      if (v) applyVariant(findVariant(v.id) || v);
    });
  }
})();




//AKfycbw_qNxdBYd7ommlfYUIbclXW4t51jXeE07n7KyUYuCSlfi89KSyr_6AaFiYWN3LONbw

//https://script.google.com/macros/s/AKfycbw_qNxdBYd7ommlfYUIbclXW4t51jXeE07n7KyUYuCSlfi89KSyr_6AaFiYWN3LONbw/exec
