class CustomVideoPlayer extends HTMLElement {
  constructor() {
    super();
    this.videoPosters = this.querySelectorAll(".deferred-media__poster-button");
    if (this.videoPosters.length === 0) return;
    this.boundLoadContent = this.loadContent.bind(this);
    this.initialize();
  }

  initialize() {
    this.isMobileView = window.innerWidth < 750;
    this.videoSectionConatiner = this.closest('.video-with-image-section');
    this.handleInitialVideoLoad();
    this.videoPosters.forEach((poster) => {
      poster.addEventListener("click", this.boundLoadContent);
    });
  }

  handleInitialVideoLoad() {
    try {
      const initialVideo = this.querySelector(`.video-section__media.${this.isMobileView ? "mobile-video" : "desktop-video"}`);
      if (initialVideo && initialVideo.dataset.autoplay === "true" && !initialVideo.getAttribute("loaded")) {
        this.loadContent(null, true, initialVideo);
      }
    } catch (error) {
      console.error("Error loading initial video:", error);
    }
  }

  loadContent(event, focus = true, videoElement = null) {
    try {
      if (typeof window.pauseAllMedia === "function") {
        window.pauseAllMedia();
      }
      const targetVideoContainer = event?.target.closest(".video-section__media") || videoElement;
      if (!targetVideoContainer || targetVideoContainer.getAttribute("loaded"))
        return;
      const templateElement = targetVideoContainer.querySelector("template");
      if (!templateElement)
        throw new Error("Template not found in video container.");
      const content = templateElement.content.firstElementChild.cloneNode(true);
      targetVideoContainer.setAttribute("loaded", "true");
      targetVideoContainer.appendChild(content);
      if (this.videoSectionConatiner ){
        this.videoSectionConatiner.setAttribute("video-playing", "true");
      }

      if (focus) content.focus();
      if (content.nodeName === "VIDEO") {
        content.play().catch((err) => console.error("Error playing video:", err));
      } else if (content.nodeName === "IFRAME") {
        this.playYouTubeVideo(content);
      }
    } catch (error) {
      console.error("Error loading video content:", error);
    }
  }

  playYouTubeVideo(iframe) {
    if (iframe.src.includes("youtube.com")) {
      iframe.src += "&autoplay=1";
    }
  }

  disconnectedCallback() {
    this.videoPosters.forEach((poster) => {
      poster.removeEventListener("click", this.boundLoadContent);
    });
  }
}

customElements.define("custom-video-player", CustomVideoPlayer);
