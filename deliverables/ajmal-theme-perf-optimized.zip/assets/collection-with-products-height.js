let resizeTimer;
function adjustProductCardContainerHeight() { 
  try {
    if (window.innerWidth >= 990) {
      const mainImageContainer = document.querySelector('.collection-with-product-container .splide__track');
      const heading = document.querySelector(".collection-products-container .collection-heading");
      const viewMore = document.querySelector(".collection-products-container .view-more-container");
      const productCardContainers = document.querySelectorAll(".collection-products-container .product-card-container");

      if (!mainImageContainer || productCardContainers.length === 0) return;

      const totalHeight = mainImageContainer.clientHeight;
      const headingHeight = heading ? heading.offsetHeight + parseFloat(getComputedStyle(heading).marginBottom) : 0;
      const viewMoreHeight = viewMore ? viewMore.offsetHeight + parseFloat(getComputedStyle(viewMore).marginTop) : 0;
      const availableHeight = totalHeight - (headingHeight + viewMoreHeight);

      productCardContainers.forEach((eachContainer) => {
        eachContainer.style.maxHeight = `${availableHeight}px`;
      });
    }
  } catch (error) {
    console.error("Error adjusting product card container height:", error);
  }
}

adjustProductCardContainerHeight();
window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(adjustProductCardContainerHeight, 200);
});
