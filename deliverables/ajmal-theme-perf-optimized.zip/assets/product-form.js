// if (!customElements.get('product-form')) {
//   customElements.define(
//     'product-form',
//     class ProductForm extends HTMLElement {
//       constructor() {
//         super();

//         this.form = this.querySelector('form');
//         this.form.querySelector('[name=id]').disabled = false;
//         this.form.addEventListener('submit', this.onSubmitHandler.bind(this));
//         this.cart = document.querySelector('cart-notification') || document.querySelector('cart-drawer');
//         this.submitButton = this.querySelector('[type="submit"]');

//         if (document.querySelector('cart-drawer')) this.submitButton.setAttribute('aria-haspopup', 'dialog');

//         this.hideErrors = this.dataset.hideErrors === 'true';
//       }

//       onSubmitHandler(evt) {
//         evt.preventDefault();
//         if (this.dataset['template'] === "product") {
//           const quantityInput = this.querySelector(".product-form .quantity__input");
//           const selectedQuantity = parseInt(quantityInput.value);
//           const availableQuantity = parseInt(this.dataset["productavailable"]);
//           if (isNaN(selectedQuantity) || isNaN(availableQuantity)) {
//               console.error("Invalid quantity values.");
//               return;
//           }
//           if (selectedQuantity > availableQuantity) {
//               this.handleErrorMessage(`Sorry, you can't add more than ${availableQuantity} ${this.dataset['producttitle']} to the cart.`);
//               return;
//           }
//       }      
//         if (this.submitButton.getAttribute('aria-disabled') === 'true') return;

//         this.handleErrorMessage();

//         this.submitButton.setAttribute('aria-disabled', true);
//         this.submitButton.classList.add('loading');
//         Array.from(this.querySelectorAll('.loading-overlay__spinner')).slice(-1)[0].classList.remove('hidden');

//         const config = fetchConfig('javascript');
//         config.headers['X-Requested-With'] = 'XMLHttpRequest';
//         delete config.headers['Content-Type'];

//         const formData = new FormData(this.form);
//         if (this.cart) {
//           formData.append(
//             'sections',
//             this.cart.getSectionsToRender().map((section) => section.id)
//           );
//           formData.append('sections_url', window.location.pathname);
//           this.cart.setActiveElement(document.activeElement);
//         }
//         config.body = formData;

//         fetch(`${routes.cart_add_url}`, config)
//           .then((response) => response.json())
//           .then((response) => {
//             if (response.status) {
//               publish(PUB_SUB_EVENTS.cartError, {
//                 source: 'product-form',
//                 productVariantId: formData.get('id'),
//                 errors: response.errors || response.description,
//                 message: response.message,
//               });
//               this.handleErrorMessage(response.description);

//               const soldOutMessage = this.submitButton.querySelector('.sold-out-message');
//               if (!soldOutMessage) return;
//               this.submitButton.setAttribute('aria-disabled', true);
//               this.submitButton.querySelector('span').classList.add('hidden');
//               soldOutMessage.classList.remove('hidden');
//               this.error = true;
//               return;
//             } else if (!this.cart) {
//               window.location = window.routes.cart_url;
//               return;
//             }

//             if (!this.error)
//               publish(PUB_SUB_EVENTS.cartUpdate, { source: 'product-form', productVariantId: formData.get('id'), cartData: response });
//             this.error = false;
//             const quickAddModal = this.closest('quick-add-modal');
//             if (quickAddModal) {
//               document.body.addEventListener(
//                 'modalClosed',
//                 () => {
//                   setTimeout(() => {
//                     this.cart.renderContents(response);
//                   });
//                 },
//                 { once: true }
//               );
//               quickAddModal.hide(true);
//             } else {
//               this.cart.renderContents(response);
//             }
//           })
//           .catch((e) => {
//             console.error(e);
//           })
//           .finally(() => {
//             this.submitButton.classList.remove('loading');
//             if (this.cart && this.cart.classList.contains('is-empty')) this.cart.classList.remove('is-empty');
//             if (!this.error) this.submitButton.removeAttribute('aria-disabled');
//             Array.from(this.querySelectorAll('.loading-overlay__spinner')).slice(-1)[0].classList.add('hidden');
//           });
//       }

//       handleErrorMessage(errorMessage = false) {
//         if (this.hideErrors) return;

//         this.errorMessageWrapper =
//           this.errorMessageWrapper || this.querySelector('.product-form__error-message-wrapper');
//         if (!this.errorMessageWrapper) return;
//         this.errorMessage = this.errorMessage || this.errorMessageWrapper.querySelector('.product-form__error-message');

//         this.errorMessageWrapper.toggleAttribute('hidden', !errorMessage);

//         if (errorMessage) {
//           this.errorMessage.textContent = errorMessage;
//         }
//       }
//     }
//   );
// }

if (!customElements.get('product-form')) {
  customElements.define(
    'product-form',
    class ProductForm extends HTMLElement {
      constructor() {
        super();

        this.form = this.querySelector('form');
        this.form.querySelector('[name=id]').disabled = false;
        this.form.addEventListener('submit', this.onSubmitHandler.bind(this));
        this.cart = document.querySelector('cart-notification') || document.querySelector('cart-drawer');
        this.submitButton = this.querySelector('[type="submit"]');

        if (document.querySelector('cart-drawer')) this.submitButton.setAttribute('aria-haspopup', 'dialog');

        this.hideErrors = this.dataset.hideErrors === 'true';

        this.setupPaymentButtonBundleInterceptor();
      }

      setupPaymentButtonBundleInterceptor() {
        // Delegation also handles accelerated checkout buttons added after the form renders.
        this.addEventListener('click', (event) => {
          const button = event.target.closest?.('.shopify-payment-button__button, .shopify-payment-button button');
          if (!button) return;
          const selectedBundles = document.querySelectorAll('.bundle-checkbox:checked');
          if (selectedBundles.length === 0) return;

          event.preventDefault();
          event.stopImmediatePropagation();

          const variantId = this.form.querySelector('[name="id"]')?.value;
          if (!variantId) return;
          button.style.pointerEvents = 'none';

          const quantity = parseInt(this.form.querySelector('[name="quantity"]')?.value || '1', 10);
          const items = [{ id: parseInt(variantId, 10), quantity }];
          selectedBundles.forEach((checkbox) => {
            if (checkbox.value) items.push({ id: parseInt(checkbox.value, 10), quantity });
          });

          const permalink = items.map((item) => `${item.id}:${item.quantity}`).join(',');
          window.location.href = `/cart/${permalink}?checkout`;
        }, true);
      }

      onSubmitHandler(evt) {
        evt.preventDefault();

        // ── Quantity validation ────────────────────────────────────
        if (this.dataset['template'] === "product") {
          const quantityInput = this.querySelector(".product-form .quantity__input");
          const selectedQuantity = parseInt(quantityInput.value);
          const availableQuantity = parseInt(this.dataset["productavailable"]);
          if (isNaN(selectedQuantity) || isNaN(availableQuantity)) {
            console.error("Invalid quantity values.");
            return;
          }
          if (selectedQuantity > availableQuantity) {
            this.handleErrorMessage(`Sorry, you can't add more than ${availableQuantity} ${this.dataset['producttitle']} to the cart.`);
            return;
          }
        }

        if (this.submitButton.getAttribute('aria-disabled') === 'true') return;

        // ── Upsell Modal Check ─────────────────────────────────────
        const productWrapper = this.closest('[data-product-id]');
        const productId = productWrapper && productWrapper.dataset.productId;
        const upsellDataEl = productId ? document.getElementById('upsell-data-' + productId) : null;

        if (upsellDataEl) {
          try {
            const upsellData = JSON.parse(upsellDataEl.textContent);
            const variantId = (this.form.querySelector('[name="id"]') || {}).value;
            const qty = parseInt((this.form.querySelector('[name="quantity"]') || {}).value || '1', 10);

            const modal = document.getElementById('upsell-modal');
            if (modal) {
              modal._pendingVariantId = variantId;
              modal._pendingQty = qty;
              modal._upsellData = upsellData;
              modal._productFormInstance = this;

              document.getElementById('upsell-modal-image').src = upsellData.upsellImage;
              document.getElementById('upsell-modal-image').alt = upsellData.upsellTitle;
              document.getElementById('upsell-modal-product-title').textContent = upsellData.upsellTitle;
              document.getElementById('upsell-modal-product-price').textContent = (upsellData.upsellPrice / 100).toLocaleString('en-US', {
                style: 'currency',
                currency: (window.Shopify && window.Shopify.currency && window.Shopify.currency.active) || 'USD'
              });

              const acceptBtn = document.getElementById('upsell-accept-btn');
              const addBothText = upsellData.addBothText || 'Yes, add both to cart';
              if (!upsellData.upsellAvailable) {
                acceptBtn.textContent = 'Out of stock — just add original';
                acceptBtn.disabled = true;
              } else {
                acceptBtn.textContent = addBothText;
                acceptBtn.disabled = false;
              }

              modal.hidden = false;
              document.body.style.overflow = 'hidden';
              return;
            }
          } catch (e) {
            console.warn('[Upsell] Error parsing upsell data, proceeding normally.', e);
          }
        }
        // ── End Upsell Check ───────────────────────────────────────

        this.proceedToCartAdd();
      }

      proceedToCartAdd(extraItems = []) {
        this.handleErrorMessage();

        this.submitButton.setAttribute('aria-disabled', true);
        this.submitButton.classList.add('loading');
        Array.from(this.querySelectorAll('.loading-overlay__spinner')).slice(-1)[0].classList.remove('hidden');

        // ── Both items (upsell accepted) — JSON body with sections ─
        if (extraItems.length > 0) {
          const sections = this.cart ? this.cart.getSectionsToRender().map((s) => s.id) : [];

          if (this.cart) this.cart.setActiveElement(document.activeElement);

          fetch('/cart/add.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              items: extraItems,
              sections: sections,
              sections_url: window.location.pathname
            })
          })
            .then((res) => res.json())
            .then((response) => {
              if (response.status) {
                this.handleErrorMessage(response.description);
                this.error = true;
                return;
              }
              if (!this.cart) {
                window.location = window.routes.cart_url;
                return;
              }
              if (!this.error) {
                publish(PUB_SUB_EVENTS.cartUpdate, { source: 'product-form' });
              }
              this.error = false;
              if (this.cart.classList.contains('is-empty')) {
                this.cart.classList.remove('is-empty');
              }
              this.cart.renderContents(response);

              // ── Start watching cart qty changes for upsell 10x sync ─
              const upsellVariantId = extraItems[1] && extraItems[1].id;
              const mainVariantId = extraItems[0] && extraItems[0].id;
              if (upsellVariantId && mainVariantId) {
                this.listenForCartQtyChanges(String(upsellVariantId), String(mainVariantId));
              }
            })
            .catch((e) => console.error('[Upsell] Cart add error:', e))
            .finally(() => this.resetSubmitButton());
          return;
        }

        // ── Normal single product flow ─────────────────────────────
        const config = fetchConfig('javascript');
        config.headers['X-Requested-With'] = 'XMLHttpRequest';
        delete config.headers['Content-Type'];

        const formData = new FormData(this.form);
        if (this.cart) {
          formData.append(
            'sections',
            this.cart.getSectionsToRender().map((section) => section.id)
          );
          formData.append('sections_url', window.location.pathname);
          this.cart.setActiveElement(document.activeElement);
        }
        config.body = formData;

        fetch(`${routes.cart_add_url}`, config)
          .then((response) => response.json())
          .then((response) => {
            if (response.status) {
              publish(PUB_SUB_EVENTS.cartError, {
                source: 'product-form',
                productVariantId: formData.get('id'),
                errors: response.errors || response.description,
                message: response.message,
              });
              this.handleErrorMessage(response.description);

              const soldOutMessage = this.submitButton.querySelector('.sold-out-message');
              if (!soldOutMessage) return;
              this.submitButton.setAttribute('aria-disabled', true);
              this.submitButton.querySelector('span').classList.add('hidden');
              soldOutMessage.classList.remove('hidden');
              this.error = true;
              return;
            } else if (!this.cart) {
              window.location = window.routes.cart_url;
              return;
            }

            if (!this.error)
              publish(PUB_SUB_EVENTS.cartUpdate, {
                source: 'product-form',
                productVariantId: formData.get('id'),
                cartData: response,
              });
            this.error = false;

            // =============================
            // Bundle Products Add To Cart
            // =============================
            const selectedBundles = document.querySelectorAll('.bundle-checkbox:checked');

            if (selectedBundles.length > 0) {

              const bundleItems = [];

              selectedBundles.forEach((checkbox) => {

                bundleItems.push({
                  id: parseInt(checkbox.value),
                  quantity: parseInt(formData.get('quantity') || 1)
                });

              });

              fetch('/cart/add.js', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                  items: bundleItems
                })
              })
                .then(() => {

                  return fetch('/cart.js');

                })
                .then(response => response.json())
                .then(cart => {

                  publish(PUB_SUB_EVENTS.cartUpdate, {
                    source: 'bundle-products',
                    cartData: cart
                  });

                })
                .catch(error => {
                  console.error('Bundle Error:', error);
                });
            }

            const quickAddModal = this.closest('quick-add-modal');
            if (!quickAddModal && selectedBundles.length === 0 &&
                window.AjmalWhiteFriday?.offerAfterAdd(this, formData, response)) return;
            if (quickAddModal) {
              document.body.addEventListener(
                'modalClosed',
                () => {
                  setTimeout(() => {
                    this.cart.renderContents(response);
                  });
                },
                { once: true }
              );
              quickAddModal.hide(true);
            } else {
              this.cart.renderContents(response);
            }
          })
          .catch((e) => { console.error(e); })
          .finally(() => { this.resetSubmitButton(); });
      }

      // ── Listen for cart updates and keep upsell qty at 10x main ──
      listenForCartQtyChanges(upsellVariantId, mainVariantId) {
        if (this._upsellSyncRegistered) return; // prevent duplicate listeners
        this._upsellSyncRegistered = true;

        if (typeof subscribe !== 'undefined' && typeof PUB_SUB_EVENTS !== 'undefined') {
          subscribe(PUB_SUB_EVENTS.cartUpdate, (data) => {
            // Skip updates triggered by our own sync to avoid infinite loop
            if (data && data.source === 'upsell-sync') return;
            this.syncUpsellQty(upsellVariantId, mainVariantId);
          });
        }
      }

      // ── Fetch cart and update upsell qty to always be 10x main ───
      syncUpsellQty(upsellVariantId, mainVariantId) {
        fetch('/cart.js')
          .then((res) => res.json())
          .then((cart) => {
            const mainItem = cart.items.find((i) => String(i.variant_id) === String(mainVariantId));
            const upsellItem = cart.items.find((i) => String(i.variant_id) === String(upsellVariantId));

            // If either item is not in cart anymore, do nothing
            if (!mainItem || !upsellItem) return;

            const expectedUpsellQty = mainItem.quantity * 10;

            // Already correct, no need to update
            if (upsellItem.quantity === expectedUpsellQty) return;

            fetch('/cart/change.js', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                id: String(upsellVariantId),
                quantity: expectedUpsellQty
              })
            })
              .then((res) => res.json())
              .then(() => {
                if (this.cart && typeof publish !== 'undefined' && typeof PUB_SUB_EVENTS !== 'undefined') {
                  publish(PUB_SUB_EVENTS.cartUpdate, { source: 'upsell-sync' });
                }
              })
              .catch((e) => console.error('[Upsell] Sync qty error:', e));
          })
          .catch((e) => console.error('[Upsell] Cart fetch error:', e));
      }

      resetSubmitButton() {
        this.submitButton.classList.remove('loading');
        if (this.cart && this.cart.classList.contains('is-empty')) this.cart.classList.remove('is-empty');
        if (!this.error) this.submitButton.removeAttribute('aria-disabled');
        Array.from(this.querySelectorAll('.loading-overlay__spinner')).slice(-1)[0].classList.add('hidden');
      }

      handleErrorMessage(errorMessage = false) {
        if (this.hideErrors) return;

        this.errorMessageWrapper =
          this.errorMessageWrapper || this.querySelector('.product-form__error-message-wrapper');
        if (!this.errorMessageWrapper) return;
        this.errorMessage =
          this.errorMessage || this.errorMessageWrapper.querySelector('.product-form__error-message');

        this.errorMessageWrapper.toggleAttribute('hidden', !errorMessage);

        if (errorMessage) {
          this.errorMessage.textContent = errorMessage;
        }
      }
    }
  );
}
