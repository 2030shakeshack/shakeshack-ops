(() => {

    /* =========================================
     FREEBIE MODAL DISABLED (SAFE MODE)
     Keeps cart drawer working normally
  ========================================== */

  window.freebieModalState = {
    deferDrawerOpen: false,
    openDrawerOnClose: false,
    selected: true,   
    active: false,
    skip: true        
  };

  return;

  const freebieModal = document.getElementById('FreebieModal');
  if (!freebieModal || !window.routes) return;

  const cartDrawer = document.querySelector('cart-drawer');
  const freebieCards = Array.from(freebieModal.querySelectorAll('[data-freebie-card]'));
  const storageKey = 'ajmalFreebieVariant';
  let activeFreebieVariantId = null;
  let activeFreebieLine = null;
  let freebieSelected = false;
  let isUpdating = false;
  const modalState = window.freebieModalState || {};
  window.freebieModalState = modalState;
  modalState.deferDrawerOpen = false;
  modalState.openDrawerOnClose = false;
  modalState.selected = false;
  modalState.active = false;
  modalState.skip = false;
  const modalSound = document.getElementById('FreebieModalSound');

  const prepareSound = () => {
    if (!modalSound) return;
    const volume = Number(modalSound.dataset.volume);
    if (Number.isFinite(volume)) {
      modalSound.volume = Math.max(0, Math.min(1, volume / 100));
    }
  };

  const playSound = () => {
    if (!modalSound) return;
    prepareSound();
    try {
      modalSound.currentTime = 0;
    } catch (error) {}
    const playPromise = modalSound.play();
    if (playPromise && typeof playPromise.catch === 'function') {
      playPromise.catch(() => {});
    }
  };

  const stopSound = () => {
    if (!modalSound) return;
    modalSound.pause();
    try {
      modalSound.currentTime = 0;
    } catch (error) {}
  };

  const supportsStorage = (() => {
    try {
      return 'localStorage' in window;
    } catch (error) {
      return false;
    }
  })();

  const jsonConfig = () => {
    if (typeof fetchConfig === 'function') return fetchConfig();
    return {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    };
  };

  const getSections = () => {
    if (!cartDrawer) return [];
    return cartDrawer.getSectionsToRender().map((section) => section.id);
  };

  const hasSkipProperty = (properties) => {
    if (!properties) return false;
    const value = properties._freebie_skip;
    return value === true || value === 'true';
  };

  const resolveSkipFromEvent = (event) => {
    if (!event || !event.cartData) return null;
    const variantId = Number(event.productVariantId || event.variantId || event.id);
    const cartData = event.cartData;

    const itemId = Number(cartData.id || cartData.variant_id);
    if (!Number.isNaN(itemId) && (!variantId || itemId === variantId)) {
      return hasSkipProperty(cartData.properties);
    }

    if (Array.isArray(cartData.items) && variantId) {
      const match = cartData.items.find((item) => Number(item.id || item.variant_id) === variantId);
      if (!match) return null;
      return hasSkipProperty(match.properties);
    }

    return null;
  };

  const formHasSkipInput = (form) => {
    if (!form) return false;
    return Boolean(form.querySelector('input[name="properties[_freebie_skip]"]'));
  };

  const updateButtons = (variantId) => {
    freebieCards.forEach((card) => {
      const cardVariantId = Number(card.dataset.variantId);
      const button = card.querySelector('[data-freebie-select]');
      const isSelected = variantId && cardVariantId === Number(variantId);

      card.classList.toggle('is-selected', isSelected);

      if (!button || button.disabled) return;

      const defaultHtml = button.getAttribute('data-default-html') || button.innerHTML;
      button.setAttribute('data-default-html', defaultHtml);
      if (isSelected) {
        button.textContent = 'Selected';
      } else {
        button.innerHTML = defaultHtml;
      }
      button.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
      button.classList.toggle('is-selected', isSelected);
    });
  };

  const findFreebieItem = (cart) => {
    if (!cart || !Array.isArray(cart.items)) return null;
    const index = cart.items.findIndex((item) => item.properties && item.properties._freebie);
    if (index === -1) return null;
    const item = cart.items[index];
    return { ...item, line: index + 1 };
  };

  const updateStateFromCart = (cart) => {
    const freebieItem = findFreebieItem(cart);
    activeFreebieVariantId = freebieItem ? Number(freebieItem.id || freebieItem.variant_id) : null;
    activeFreebieLine = freebieItem ? freebieItem.line : null;
    freebieSelected = Boolean(freebieItem);

    // Keep the selected flag in sync with actual cart state
    modalState.selected = freebieSelected;

    // Edge case: If freebie exists but no regular products are in cart, auto-remove the freebie
    if (freebieSelected && cart.items) {
      const nonFreebieItems = cart.items.filter((item) => !item.properties || !item.properties._freebie);
      if (nonFreebieItems.length === 0) {
        // All items are freebie, remove it
        if (activeFreebieLine) {
          removeFreebie(activeFreebieLine)
            .then(() => {
              // After removal, fetch updated cart and re-render via the proper cart update mechanism
              return fetchCart().then((updatedCart) => {
                if (typeof publish === 'function') {
                  // Use the built-in pub/sub system to trigger cart update
                  publish(PUB_SUB_EVENTS.cartUpdate, {
                    source: 'freebie-removal',
                    cartData: updatedCart,
                  });
                }
              });
            })
            .catch(() => {});
          return freebieSelected;
        }
      }
    }

    if (supportsStorage) {
      if (freebieSelected && activeFreebieVariantId) {
        localStorage.setItem(storageKey, String(activeFreebieVariantId));
      } else {
        localStorage.removeItem(storageKey);
      }
    }

    updateButtons(activeFreebieVariantId);
    disableFreebieQuantityControls();
    return freebieSelected;
  };

  const disableFreebieQuantityControls = () => {
    if (!freebieSelected || !activeFreebieLine) return;

    // Find the quantity input for the freebie item (by data-index)
    const freebieQuantityInput = document.querySelector(
      `[data-index="${activeFreebieLine}"] .quantity__input, 
       #Drawer-quantity-${activeFreebieLine}, 
       #Quantity-${activeFreebieLine}`
    );

    if (!freebieQuantityInput) return;

    // Disable the quantity input
    freebieQuantityInput.disabled = true;
    freebieQuantityInput.min = freebieQuantityInput.value; // Set min to current value
    freebieQuantityInput.max = freebieQuantityInput.value; // Set max to current value

    // Disable the +/- buttons around the input
    const quantityContainer = freebieQuantityInput.closest('quantity-input') || freebieQuantityInput.closest('.quantity');
    if (quantityContainer) {
      const buttons = quantityContainer.querySelectorAll('button[name="plus"], button[name="minus"]');
      buttons.forEach((btn) => {
        btn.disabled = true;
        btn.style.opacity = '0.5';
        btn.style.cursor = 'not-allowed';
      });
    }
  };

  const fetchCart = async () => {
    const response = await fetch(`${routes.cart_url}.js`, { credentials: 'same-origin' });
    if (!response.ok) throw new Error('Unable to fetch cart');
    return response.json();
  };

  const openModal = async ({ deferDrawerOpen = false } = {}) => {
    if (freebieModal.hasAttribute('open')) return;

    modalState.deferDrawerOpen = deferDrawerOpen;
    modalState.openDrawerOnClose = deferDrawerOpen;
    modalState.active = true;

    if (!activeFreebieVariantId && supportsStorage) {
      const stored = localStorage.getItem(storageKey);
      if (stored) activeFreebieVariantId = Number(stored);
    }

    if (activeFreebieVariantId) {
      updateButtons(activeFreebieVariantId);
    } else {
      try {
        updateStateFromCart(await fetchCart());
      } catch (error) {}
    }

    if (!freebieModal.hasAttribute('open')) {
      freebieModal.show(document.activeElement || document.body);
    }
    playSound();
  };

  const openDrawerIfNeeded = () => {
    if (!cartDrawer || cartDrawer.classList.contains('active')) return;
    cartDrawer.open();
  };

  const closeModal = ({ openDrawer } = {}) => {
    if (!freebieModal.hasAttribute('open')) return;
    if (openDrawer || modalState.openDrawerOnClose) {
      modalState.openDrawerOnClose = true;
    }
    stopSound();
    freebieModal.hide();
    if (cartDrawer && cartDrawer.classList.contains('active')) {
      document.body.classList.add('overflow-hidden');
    }
    // Notify listeners that the freebie modal closed
    try {
      window.dispatchEvent(new Event('freebie:closed'));
      if (openDrawer || modalState.openDrawerOnClose) {
        window.dispatchEvent(new Event('freebie:productSelected'));
      }
      modalState.deferDrawerOpen = false;
    } catch (e) {}
  };

  const removeFreebie = async (line) => {
    const config = jsonConfig();
    config.body = JSON.stringify({ line, quantity: 0 });
    await fetch(routes.cart_change_url, config);
  };

  const addFreebie = async (variantId) => {
    const body = {
      items: [
        {
          id: variantId,
          quantity: 1,
          properties: { _freebie: 'true' },
        },
      ],
    };

    const sections = getSections();
    if (sections.length) {
      body.sections = sections;
      body.sections_url = window.location.pathname;
    }

    const config = jsonConfig();
    config.body = JSON.stringify(body);
    const response = await fetch(routes.cart_add_url, config);
    if (!response.ok) throw new Error('Unable to add freebie');

    const data = await response.json();
    if (cartDrawer && data.sections) {
      cartDrawer.renderContents(data);
    }
  };

  const handleSelect = async (button) => {
    if (isUpdating) return;
    const card = button.closest('[data-freebie-card]');
    if (!card) return;

    const variantId = Number(card.dataset.variantId);
    if (!variantId) return;

    isUpdating = true;
    button.setAttribute('aria-busy', 'true');
    const wasDisabled = button.disabled;
    const spinner = button.querySelector('.loading-overlay__spinner');
    button.classList.add('loading');
    button.disabled = true;
    if (spinner) spinner.classList.remove('hidden');

    try {
      const currentVariantId = activeFreebieVariantId;
      let lineToRemove = activeFreebieLine;

      if (currentVariantId && currentVariantId === variantId) {
        activeFreebieVariantId = variantId;
        freebieSelected = true;
        updateButtons(variantId);
        closeModal({ openDrawer: true });
        return;
      }

      if (!lineToRemove && currentVariantId) {
        try {
          updateStateFromCart(await fetchCart());
          lineToRemove = activeFreebieLine;
        } catch (error) {}
      }

      if (lineToRemove) {
        await removeFreebie(lineToRemove);
      }

      await addFreebie(variantId);

      activeFreebieVariantId = variantId;
      freebieSelected = true;
      activeFreebieLine = null;
      updateButtons(variantId);
      if (supportsStorage) {
        localStorage.setItem(storageKey, String(variantId));
      }
      closeModal({ openDrawer: true });

      fetchCart()
        .then(updateStateFromCart)
        .catch(() => {});
    } catch (error) {
      console.error(error);
    } finally {
      isUpdating = false;
      button.classList.remove('loading');
      if (spinner) spinner.classList.add('hidden');
      if (!wasDisabled) button.disabled = false;
      button.removeAttribute('aria-busy');
    }
  };

  document.addEventListener('click', (event) => {
    const openButton = event.target.closest('[data-freebie-open]');
    if (openButton) {
      event.preventDefault();
      openModal();
      return;
    }

    const closeButton = event.target.closest('[data-freebie-close]');
    if (closeButton) {
      event.preventDefault();
      closeModal();
      return;
    }

    const selectButton = event.target.closest('[data-freebie-select]');
    if (selectButton) {
      event.preventDefault();
      handleSelect(selectButton);
      return;
    }

    // If a product form submit button is clicked and freebie hasn't been selected,
    // preemptively set deferDrawerOpen flag so cart-drawer knows to wait
    const submitButton = event.target.closest('product-form [type="submit"], multi-product-form [type="submit"]');
    if (submitButton) {
      const form = submitButton.closest('form');
      const skipFreebie = formHasSkipInput(form);
      modalState.skip = skipFreebie;

      if (skipFreebie) {
        modalState.deferDrawerOpen = false;
        modalState.openDrawerOnClose = false;
        return;
      }

      if (!freebieSelected) {
        modalState.deferDrawerOpen = true;
        modalState.openDrawerOnClose = true;
      }
    }
  });

  if (typeof subscribe === 'function') {
    subscribe(PUB_SUB_EVENTS.cartUpdate, async (event) => {
      if (!event) return;

      const skipFromEvent = resolveSkipFromEvent(event);
      if (skipFromEvent === true) {
        modalState.skip = true;
        modalState.deferDrawerOpen = false;
        modalState.openDrawerOnClose = false;
      } else if (skipFromEvent === false) {
        modalState.skip = false;
      }

      let cartData = event.cartData;
      if (!cartData || !Array.isArray(cartData.items)) {
        try {
          cartData = await fetchCart();
        } catch (error) {
          return;
        }
      }

      updateStateFromCart(cartData);

      if (isUpdating) return;
      if (event.source !== 'product-form') return;
      if (modalState.skip) return;

      if (!freebieSelected) {
        // Freebie hasn't been selected yet, so open the modal
        modalState.deferDrawerOpen = true;
        modalState.openDrawerOnClose = true;
        setTimeout(() => {
          openModal({ deferDrawerOpen: true });
        }, 50);
      }
    });
  }

  if (supportsStorage) {
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      activeFreebieVariantId = Number(stored);
      updateButtons(activeFreebieVariantId);
    }
  }

  fetchCart()
    .then(updateStateFromCart)
    .catch(() => {});

  document.body.addEventListener('modalClosed', () => {
    if (!modalState.active) return;

    modalState.active = false;
    const shouldOpenDrawer = modalState.openDrawerOnClose;
    modalState.openDrawerOnClose = false;
    modalState.deferDrawerOpen = false;
    stopSound();

    if (shouldOpenDrawer) {
      openDrawerIfNeeded();
    }
  });

  // Expose disableFreebieQuantityControls to window for use in cart-drawer.js
  window.disableFreebieQuantityControls = disableFreebieQuantityControls;
})();
