if (!customElements.get('sale-tabs')) {
  class SaleTabs extends Carousel {
    constructor() {
      super();
      this.sectionId = this.dataset.sectionId;
      this.cache = new Map();
      this.init();
    }

    init() {
      this.mainSection = this.closest('.shopify-section') 
        || document.querySelector(`.sale-tabs-${this.sectionId}`) 
        || document.querySelector(`.sale-collection-tabs-${this.sectionId}`)
        || this.parentElement;
      if (!this.mainSection) return;

      this.shimmerContainer = this.mainSection.querySelector('.sale-tabs-shimmer');
      this.listContainer = this.querySelector('.splide__list') || this.querySelector('.sale-products-container');
      this.viewAllBtn = this.mainSection.querySelector('.sale-tabs-view-all');

      // Pre-cache initial server-rendered collection
      const initialSubTab = this.mainSection.querySelector('.sale-sub-tab.active');
      if (initialSubTab && initialSubTab.dataset.collectionHandle && this.listContainer && this.listContainer.children.length > 0) {
        this.cache.set(initialSubTab.dataset.collectionHandle, this.listContainer.innerHTML);
      } else if (initialSubTab && initialSubTab.dataset.collectionHandle) {
        this.loadCollection(initialSubTab);
      }

      this.bindEvents();
    }

    bindEvents() {
      // Main Offer Tabs (e.g. #96, #196 in sale-tabs.liquid)
      const mainTabsContainer = this.mainSection.querySelector('.sale-main-tabs');
      if (mainTabsContainer) {
        mainTabsContainer.addEventListener('click', (e) => {
          const tabBtn = e.target.closest('.sale-main-tab');
          if (!tabBtn) return;
          this.handleMainTabClick(tabBtn);
        });
      }

      // Sub-Tabs in groups (sale-tabs.liquid)
      const subTabsContainers = this.mainSection.querySelectorAll('.sale-sub-tabs-group');
      subTabsContainers.forEach((group) => {
        group.addEventListener('click', (e) => {
          const subTabBtn = e.target.closest('.sale-sub-tab');
          if (!subTabBtn) return;
          this.handleSubTabClick(subTabBtn);
        });
      });

      // Sub-Tabs in a single bar (sale-collection-tabs.liquid)
      const singleSubTabsBar = this.mainSection.querySelector('.sale-sub-tabs-bar');
      if (singleSubTabsBar) {
        singleSubTabsBar.addEventListener('click', (e) => {
          const subTabBtn = e.target.closest('.sale-sub-tab');
          if (!subTabBtn) return;
          this.handleSubTabClick(subTabBtn);
        });
      }
    }

    handleMainTabClick(tabBtn) {
      const blockId = tabBtn.dataset.blockId;
      if (!blockId) return;

      // Update main tab active states
      this.mainSection.querySelectorAll('.sale-main-tab').forEach((tab) => {
        const isActive = tab === tabBtn;
        tab.classList.toggle('active', isActive);
        tab.setAttribute('aria-selected', isActive ? 'true' : 'false');
      });

      // Show corresponding sub-tabs group
      this.mainSection.querySelectorAll('.sale-sub-tabs-group').forEach((group) => {
        const isMatch = group.dataset.blockId === blockId;
        group.classList.toggle('hidden', !isMatch);
      });

      // Find the active or first sub-tab in this group
      const activeGroup = this.mainSection.querySelector(`.sale-sub-tabs-group[data-block-id="${blockId}"]`);
      if (activeGroup) {
        let activeSubTab = activeGroup.querySelector('.sale-sub-tab.active');
        if (!activeSubTab) {
          activeSubTab = activeGroup.querySelector('.sale-sub-tab');
          if (activeSubTab) {
            activeSubTab.classList.add('active');
            activeSubTab.setAttribute('aria-selected', 'true');
          }
        }
        if (activeSubTab) {
          this.loadCollection(activeSubTab);
        }
      }
    }

    handleSubTabClick(subTabBtn) {
      const parentContainer = subTabBtn.closest('.sale-sub-tabs-group') || subTabBtn.closest('.sale-sub-tabs-bar');
      if (parentContainer) {
        parentContainer.querySelectorAll('.sale-sub-tab').forEach((tab) => {
          const isActive = tab === subTabBtn;
          tab.classList.toggle('active', isActive);
          tab.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });
      } else {
        this.mainSection.querySelectorAll('.sale-sub-tab').forEach((tab) => {
          const isActive = tab === subTabBtn;
          tab.classList.toggle('active', isActive);
          tab.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });
      }
      this.loadCollection(subTabBtn);
    }

    async loadCollection(subTabBtn) {
      const collectionHandle = subTabBtn.dataset.collectionHandle;
      const collectionUrl = subTabBtn.dataset.collectionUrl || (collectionHandle ? `/collections/${collectionHandle}` : '');
      const rawTabTitle = (subTabBtn.dataset.tabTitle !== undefined ? subTabBtn.dataset.tabTitle : (subTabBtn.dataset.subTabTitle || '')).trim();

      // Update View All button
      if (this.viewAllBtn) {
        if (collectionUrl) {
          this.viewAllBtn.href = collectionUrl;
          const textPrefix = this.viewAllBtn.dataset.textPrefix || 'VIEW ALL';
          const appendTitle = this.viewAllBtn.dataset.appendTabTitle === 'true';
          const labelSpan = this.viewAllBtn.querySelector('.view-all-label');
          if (labelSpan) {
            if (appendTitle && rawTabTitle) {
              labelSpan.textContent = `${textPrefix} ${rawTabTitle}`;
            } else {
              labelSpan.textContent = textPrefix;
            }
          }
          this.viewAllBtn.classList.remove('hidden');
        } else {
          this.viewAllBtn.classList.add('hidden');
        }
      }

      if (!collectionHandle) {
        if (this.listContainer) this.listContainer.innerHTML = '';
        return;
      }

      // Check client cache
      if (this.cache.has(collectionHandle)) {
        this.renderSlides(this.cache.get(collectionHandle));
        return;
      }

      // Show shimmer loader
      if (this.shimmerContainer) this.shimmerContainer.classList.remove('hidden');
      this.classList.add('hidden');

      try {
        const pathMatch = window.location.pathname.match(/^\/([a-zA-Z]{2}(-[a-zA-Z]{2})?)(?=\/|$)/);
        const langPrefix = pathMatch ? `/${pathMatch[1]}` : '';
        const url = `${langPrefix}/collections/${collectionHandle}?section_id=${this.sectionId}`;

        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP error ${response.status}`);
        const text = await response.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(text, 'text/html');
        const content = doc.querySelector('[data-ajax-products]');
        const html = content ? content.innerHTML.trim() : '';

        this.cache.set(collectionHandle, html);
        this.renderSlides(html);
      } catch (err) {
        console.error('Error loading sale tab collection:', err);
        if (this.shimmerContainer) this.shimmerContainer.classList.add('hidden');
        this.classList.remove('hidden');
      }
    }

    renderSlides(html) {
      if (!this.listContainer) return;
      if (this.shimmerContainer) this.shimmerContainer.classList.add('hidden');
      this.classList.remove('hidden');

      const departingIds = new Set(Array.from(this.listContainer.querySelectorAll('[data-nm-block]'), panel => 'nm-overlay-' + panel.dataset.nmBlock));
      document.querySelectorAll('[data-nm-overlay]').forEach(overlay => {
        if (departingIds.has(overlay.id)) overlay.remove();
      });
      this.listContainer.innerHTML = html;
      if (this.carousel) {
        this.carousel.go(0);
      }
      if (typeof this.refreshSlider === 'function') {
        this.refreshSlider();
      }
    }
  }

  customElements.define('sale-tabs', SaleTabs);
}

