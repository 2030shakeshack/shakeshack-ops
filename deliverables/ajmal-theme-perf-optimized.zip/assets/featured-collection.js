if (!customElements.get("featured-collection")) {
  class FeaturedCollection extends Carousel {
    constructor() {
      super();
      this.sectionId = this.dataset.sectionId;
      this.currentCollection = null;
      this.handleTabClick = this.handleTabClick.bind(this);
      this.init();
    }

    init() {
      this.mainSectionContainer = document.querySelector(`.featured-collection-${this.sectionId}`);
      this.tabsContainer = this.mainSectionContainer.querySelector(".featured-collection-tab-container");
      this.listContainer = this.querySelector(".product-main-container");
      this.shimmerContainer = this.mainSectionContainer.querySelector(".shimmer-container");
      if (this.tabsContainer && !this.tabsContainer.dataset.listenerAdded) {
        this.tabsContainer.addEventListener("click", this.handleTabClick);
        this.tabsContainer.dataset.listenerAdded = "true"; 
      }
    }

    async handleTabClick(event) {
      const tab = event.target.closest(".featured-collection-tab");
      if (!tab || !tab.dataset.collectionHandle) return; // Exit if clicking on empty space
      const collectionHandle = tab.dataset.collectionHandle;
      if (this.currentCollection === collectionHandle) return; // Prevent duplicate fetch calls
      this.currentCollection = collectionHandle;
      this.tabsContainer.querySelectorAll(".featured-collection-tab").forEach((eachTab) => {
        eachTab.classList.toggle("active-collection-tab", eachTab === tab);
      });
      this.mainSectionContainer.querySelectorAll(".collection-view-all").forEach((eachViewEle) => {
        eachViewEle.classList.toggle("hidden", eachViewEle.dataset.collectionTab !== collectionHandle);
      });
      const pathMatch = window.location.pathname.match(/^\/(en)(?=\/|$)/);
      const langPrefix = pathMatch ? `/${pathMatch[1]}` : '';

      const url = `${langPrefix}/collections/${collectionHandle}?section_id=${this.sectionId}`;
      try {
        this.listContainer.innerHTML = "";
        this.shimmerContainer.classList.remove("hidden");
        this.classList.add('hidden')

        const response = await fetch(url);
        if (!response.ok) throw new Error(`Failed to fetch ${url} - Status: ${response.status}`);
        
        const text = await response.text();
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = text;
        const newItems = tempDiv.querySelector(".updated-content");

        if (!newItems) throw new Error("No updated content found in response.");

        this.updateCollection(newItems.innerHTML);
      } catch (error) {
        console.error("Error updating featured collection:", error);
      }
    }

    updateCollection(content) {
      if (!this.listContainer) {
        console.error("Product container not found.");
        return;
      }
      this.shimmerContainer.classList.add("hidden");
      this.classList.remove('hidden')
      this.listContainer.innerHTML = content;
      this.refreshSlider();
    }
  }

  customElements.define("featured-collection", FeaturedCollection);
}
